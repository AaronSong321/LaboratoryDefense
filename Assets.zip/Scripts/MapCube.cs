﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.EventSystems;

public class MapCube : MonoBehaviour
{
    internal GameObject turretGo;
    internal TurretData turretData;
    internal int currentLevel = 0;

    public GameObject buildEffect;
    private Renderer mapRenderer;
    private Color color;

    void Awake()
    {
    }
    void Start()
    {
        mapRenderer = GetComponent<Renderer>();
        currentLevel = 0;
    }

    internal void BuildTurret(TurretData turretData)
    {
        this.turretData = turretData;
        currentLevel = 1;
        turretGo = Instantiate(turretData.turretPrefab[0], transform.position, Quaternion.identity);
        turretGo.GetComponent<Turret>().ReadFromTurretData(turretData, currentLevel);
        GameObject effect = Instantiate(buildEffect, transform.position, Quaternion.identity);
        Destroy(effect, 1.5f);
    }

    internal void UpgradeTurret()
    {
        GameObject tempEffect;
        switch (currentLevel)
        {
            case 0: return;
            case 1: Destroy(turretGo);
                turretGo = Instantiate(turretData.turretPrefab[1], transform.position, Quaternion.identity);
                tempEffect = Instantiate(buildEffect, transform.position, Quaternion.identity);
                Destroy(tempEffect, 1.5f);
                currentLevel = 2;
                turretGo.GetComponent<Turret>().ReadFromTurretData(turretData, currentLevel);
                break;
            case 2: Destroy(turretGo);
                turretGo = Instantiate(turretData.turretPrefab[2], transform.position, Quaternion.identity);
                tempEffect = Instantiate(buildEffect, transform.position, Quaternion.identity);
                Destroy(tempEffect, 1.5f);
                currentLevel = 3;
                turretGo.GetComponent<Turret>().ReadFromTurretData(turretData, currentLevel);
                break;
            case 3: return;
        }
    }
    
    internal void DestroyTurret()
    {
        Destroy(turretGo);
        currentLevel = 0;
        turretGo = null;
        turretData = null;
        GameObject effect = Instantiate(buildEffect, transform.position, Quaternion.identity);
        Destroy(effect, 1.5f);
    }
    
    void OnMouseEnter()
    {
        if (turretGo == null && EventSystem.current.IsPointerOverGameObject()==false)
        {
            color = Color.green;
            color.a /= 4;
            mapRenderer.material.color = color;
        }
    }
    void OnMouseExit()
    {
        color = Color.white;
        color.a /= 4;
        mapRenderer.material.color = color;
    }
}
