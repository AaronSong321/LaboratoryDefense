﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Turret : MonoBehaviour
{
    public enum AttackType { bullet, explosive, tesla, flame, nuclear, unknown }
    public enum TargetType { ground, air, ground_all, ground_air, unknown }
    public enum TurretName { MG, CH, PB, SP, ST, PM, RL, PS, TF, TD, FT, MC, MW}
    public enum AnimosityMode { fifo, intelligent, complex}

    internal int level;
    internal TurretName turretName;
    internal int attackSpeed;
    internal int minRange;
    internal int maxRange;
    internal TargetType targetType;
    internal ImmediateCube ic;
    internal ExplosionCube ec;
    internal FiringCube fc;
    internal SlowCube sc;
    internal StunCube tc;

    public GameObject bulletPrefab;
    public Transform firePosition;
    public Transform head;

    private SphereCollider minSphereCollider;
    private SphereCollider maxSphereCollider;
    private List<GameObject> enemies = new List<GameObject>();
    private List<GameObject> enemiesCantAttack = new List<GameObject>();
    private float attackRateTime = 1;
    private float timer = 0;

    void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Enemy")
        {
            if (enemies.Contains(col.gameObject))
            {
                enemies.Remove(col.gameObject);
                enemiesCantAttack.Add(col.gameObject);
            }
            else
            {
                enemies.Add(col.gameObject);
                if (enemies[0] != null && this * enemies[0].GetComponent<Enemy>() < this * enemies[enemies.Count - 1].GetComponent<Enemy>())
                {
                    GameObject t = enemies[enemies.Count - 1];
                    enemies[enemies.Count - 1] = enemies[0];
                    enemies[0] = t;
                }
            }
        }
    }
    void OnTriggerExit(Collider col)
    {
        if (col.tag == "Enemy")
        {
            if (enemies.Contains(col.gameObject))
            {
                enemies.Remove(col.gameObject);
            }
            else
            {
                enemiesCantAttack.Remove(col.gameObject);
                enemies.Add(col.gameObject);
                if (enemies[0] != null && this * enemies[0].GetComponent<Enemy>() < this * enemies[enemies.Count - 1].GetComponent<Enemy>())
                {
                    GameObject t = enemies[enemies.Count - 1];
                    enemies[enemies.Count - 1] = enemies[0];
                    enemies[0] = t;
                }
            }
        }
    }

    internal void ReadFromTurretData(TurretData data, int level = 0)
    {
        turretName = data.turretName;
        targetType = data.targetType;

        attackSpeed = data.levels[level - 1].attackSpeed;
        minRange = data.levels[level - 1].minRange;
        maxRange = data.levels[level - 1].maxRange;
        if (data.levels[level - 1].ic != null)
            ic = new ImmediateCube(data.levels[level - 1].ic);
        if (data.levels[level - 1].ec != null)
            ec = new ExplosionCube(data.levels[level - 1].ec);
        if (data.levels[level-1].fc != null)
            fc = new FiringCube(data.levels[level - 1].fc);
        if (data.levels[level-1].sc != null)
            sc = new SlowCube(data.levels[level - 1].sc);
        if (data.levels[level-1].tc != null)
            tc = new StunCube(data.levels[level - 1].tc);

        attackRateTime = 100f / attackSpeed;
        
        minSphereCollider = gameObject.AddComponent<SphereCollider>();
        minSphereCollider.isTrigger = true;
        minSphereCollider.center = new Vector3(0, 0.5f, 0);
        minSphereCollider.radius = minRange / 20;
        
        maxSphereCollider = gameObject.AddComponent<SphereCollider>();
        maxSphereCollider.isTrigger = true;
        maxSphereCollider.center = new Vector3(0, 0.5f, 0);
        maxSphereCollider.radius = maxRange / 20;
    }

    void Awake()
    {

    }
    void Start()
    {
        timer = attackRateTime;
    }
    void Update()
    {
        if (enemies.Count > 0 && enemies[0] != null)
        {
            Vector3 targetPosition = enemies[0].transform.position;
            targetPosition.y = head.position.y;
            head.LookAt(targetPosition);
        }
        timer += Time.deltaTime;
        if (enemies.Count > 0 && timer >= attackRateTime)
        {
            timer = 0;
            Attack();
        }
    }

    internal void AppendData(TurretData data, int level = 1)
    {
        switch(level)
        {
            case 1: attackSpeed = data.levels[0].attackSpeed;
                minRange = data.levels[0].minRange;
                maxRange = data.levels[0].maxRange;
                attackRateTime = 100f / attackSpeed;
                break;
            case 2:
                attackSpeed = data.levels[1].attackSpeed;
                minRange = data.levels[1].minRange;
                maxRange = data.levels[1].maxRange;
                attackRateTime = 100f / attackSpeed;
                break;
            case 3:
                attackSpeed = data.levels[2].attackSpeed;
                minRange = data.levels[2].minRange;
                maxRange = data.levels[2].maxRange;
                attackRateTime = 100f / attackSpeed;
                break;
        }
    }

    void GenerateBullet(GameObject enemy)
    {
        GameObject bullet = Instantiate(bulletPrefab, firePosition.position, firePosition.rotation);
        if (ic != null && ic.enable == true) bullet.GetComponent<BulletObj>().ic = new ImmediateCube(ic);
        else bullet.GetComponent<BulletObj>().ic = null;
        if (ec != null && ec.enable == true) bullet.GetComponent<BulletObj>().ec = new ExplosionCube(ec);
        else bullet.GetComponent<BulletObj>().ec = null;
        if (fc != null && fc.enable == true) bullet.GetComponent<BulletObj>().fc = new FiringCube(fc);
        else bullet.GetComponent<BulletObj>().fc = null;
        if (sc != null && sc.enable == true) bullet.GetComponent<BulletObj>().sc = new SlowCube(sc);
        else bullet.GetComponent<BulletObj>().sc = null;
        if (tc != null && tc.enable == true) bullet.GetComponent<BulletObj>().tc = new StunCube(tc);
        else bullet.GetComponent<BulletObj>().tc = null;
        bullet.GetComponent<BulletObj>().SetTarget(enemy);
    }

    void Attack()
    {
        UpdateEnemies();
        if (enemies.Count > 0)
        {
            if (targetType == TargetType.ground_all)
                foreach (GameObject enemy in enemies)
                    GenerateBullet(enemy);
            else GenerateBullet(enemies[0]);
        }
        else timer = attackRateTime;
    }

    void UpdateEnemies()
    {
        List<int> emptyIndex = new List<int>();
        for (int index = 0; index < enemies.Count; index++)
            if (enemies[index] == null)emptyIndex.Add(index);
        for (int i = 0; i < emptyIndex.Count; i++) enemies.RemoveAt(emptyIndex[i] - i);
        CalculateAnimosity(AnimosityMode.intelligent);
    }
    
    void CalculateAnimosity(AnimosityMode mode = AnimosityMode.fifo)
    {
        switch(mode)
        {
            case AnimosityMode.fifo: return;
            case AnimosityMode.complex:
                List<AnimosityPair> pairs = new List<AnimosityPair>(enemies.Count);
                for (int i = 0; i < enemies.Count; i++)
                    pairs[i] = new AnimosityPair(this, enemies[i].GetComponent<Enemy>());
                pairs.Sort();

                for (int i = 0; i < enemies.Count; i++)
                    enemies[i] = pairs[i].enemy.gameObject;
                return;
            case AnimosityMode.intelligent:
                for (int i = 0; i < enemies.Count; i++)
                    for (int j = i+1; j < enemies.Count; j++)
                        if (this*enemies[i].GetComponent<Enemy>() < this*enemies[j].GetComponent<Enemy>())
                        {
                            GameObject t = enemies[j];
                            enemies[j] = enemies[i];
                            enemies[i] = t;
                        }
                return;
        }
    }

    public static AttackType GetAttackType(string s)
    {
        if (s.Equals("bullet")) return AttackType.bullet;
        if (s.Equals("explosive")) return AttackType.explosive;
        if (s.Equals("tesla")) return AttackType.tesla;
        if (s.Equals("flame")) return AttackType.flame;
        if (s.Equals("nuclear")) return AttackType.nuclear;
        return AttackType.unknown;
    }

    public static TargetType GetTargetType(string s)
    {
        if (s.Equals("ground")) return TargetType.ground;
        if (s.Equals("air")) return TargetType.air;
        if (s.Equals("ground_all")) return TargetType.air;
        if (s.Equals("ground_air")) return TargetType.ground_air;
        return TargetType.unknown;
    }

    public static string GetChineseString(TurretName t)
    {
        switch(t)
        {
            case TurretName.MG: return "哨兵枪";
            case TurretName.CH: return "弩炮";
            case TurretName.PB: return "机枪碉堡";
            case TurretName.SP: return "狙击塔";
            case TurretName.ST: return "榴弹发射器";
            case TurretName.RL: return "火箭弹";
            case TurretName.PM: return "导弹塔";
            case TurretName.PS: return "电击塔";
            case TurretName.TF: return "变压器";
            case TurretName.TD: return "闪电塔";
            case TurretName.FT: return "火焰喷射器";
            case TurretName.MC: return "燃烧瓶";
            case TurretName.MW: return "微波塔";
            default: return "未知塔";
        }
    }

    public static GiantPreAnimoPair operator *(Turret t, Enemy e)
    {
        return new GiantPreAnimoPair(t, e);
    }
}
