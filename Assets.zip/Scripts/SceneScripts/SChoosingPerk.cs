﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


class SChoosingPerk : MonoBehaviour
{
    public enum PerkType {MM, MB, FR, TS, unknown };
    public PerkType GetPerkType(String s)
    {
        switch(s)
        {
            case "MM": return PerkType.MM;
            case "MB": return PerkType.MB;
            case "FR": return PerkType.FR;
            case "TS": return PerkType.TS;
        }
        return PerkType.unknown;
    }

    OutgameSettings outgameSettings;

    ToggleGroup TGMain;
        Toggle TOverview;
        Toggle TPerk;
        Toggle TOptions;
        Toggle TExit;

    CanvasGroup CGOverview;
        CanvasGroup CGMapChoosing;
            Dropdown DDMapChoosing;
        CanvasGroup CGDifficultyChoosing;
            Dropdown DDDifficultyChoosing;
        //CanvasGroup CGSquadInfo;
            //CanvasGroup CGPlayer1Info;
            //CanvasGroup CGPlayer2Info;
            //CanvasGroup CGPlayer3Info;
            Button BReady;
            Text XP1PerkLevel;
            Text XP1Name;

    CanvasGroup CGPerk;
        CanvasGroup CGSelectingPerk;
            CanvasGroup CGPerkMM;
            Text TMMLevel;
            CanvasGroup CGPerkMB;
            Text TMBLevel;
            CanvasGroup CGPerkFR;
            Text TFRLevel;
            CanvasGroup CGPerkTS;
            Text TTSLevel;
        ToggleGroup TGSelectingPerk;
            Toggle TPerkMM;
            Toggle TPerkMB;
            Toggle TPerkFR;
            Toggle TPerkTS;
        CanvasGroup CGAbilitiesSelected;
            GameObject I10Up;
            GameObject I10Down;
            GameObject I20Up;
            GameObject I20Down;
            GameObject I30Up;
            GameObject I30Down;
            GameObject I40Up;
            GameObject I40Down;
            GameObject I50Up;
            GameObject I50Down;
        CanvasGroup CGPerkConfiguration;
            Text TPerkConfiguration;

    CanvasGroup CGOptions;
        Dropdown DLanguage;

    CanvasGroup CGExit;
        Button BExitToMainMenu;
        Button BExitGame;

    List<String> mapString = new List<string>
    {
        "基础地图"
    };
    List<String> difficultyString = new List<String>
    {
        "理想化的", "势均力敌的", "富有挑战的", "令人绝望的"
    };
    List<String> languageString = new List<string>
    {
        "中文（简体）", "English"
    };

    public class ChangePerkEventArgs : EventArgs
    {
        public Perk.PerkName newPerk;
        public ChangePerkEventArgs(Perk.PerkName newPerk)
        {
            this.newPerk = newPerk;
        }
    }
    public delegate void ChangePerkEventHandler(object sender, ChangePerkEventArgs e);
    public event ChangePerkEventHandler ChangePerkEvent;

    public class ChangeAbilityEventArgs : EventArgs
    {
        public int levelOfAbility;
        public Player.PerkInfo.PerkChosenState state;
        public ChangeAbilityEventArgs(int levelOfAbility, Player.PerkInfo.PerkChosenState state)
        {
            this.levelOfAbility = levelOfAbility;
            this.state = state;
        }
    }
    public delegate void ChangeAbilityEventHandler(object sender, ChangeAbilityEventArgs e);
    public event ChangeAbilityEventHandler ChangeAbilityEvent;

    void Awake()
    {
        TGMain = GameObject.Find("CMain/TGMain").GetComponent<ToggleGroup>();
        TOverview = GameObject.Find("CMain/TGMain/TOverview").GetComponent<Toggle>();
        TPerk = GameObject.Find("CMain/TGMain/TPerk").GetComponent<Toggle>();
        TOptions = GameObject.Find("CMain/TGMain/TOptions").GetComponent<Toggle>();
        TExit = GameObject.Find("CMain/TGMain/TExit").GetComponent<Toggle>();

        CGOverview = GameObject.Find("CMain/CGOverview").GetComponent<CanvasGroup>();
        CGMapChoosing = GameObject.Find("CMain/CGOverview/MapChoosing").GetComponent<CanvasGroup>();
        DDMapChoosing = GameObject.Find("CMain/CGOverview/MapChoosing/Dropdown").GetComponent<Dropdown>();
        DDMapChoosing.options.Clear();
        foreach (String map in mapString)
        {
            Dropdown.OptionData optionData = new Dropdown.OptionData
            {
                text = map
            };
            DDMapChoosing.options.Add(optionData);
        }
        DDMapChoosing.captionText.text = mapString[0];
        CGDifficultyChoosing = GameObject.Find("CMain/CGOverview/DifficultyChoosing").GetComponent<CanvasGroup>();
        DDDifficultyChoosing = GameObject.Find("CMain/CGOverview/DifficultyChoosing/Dropdown").GetComponent<Dropdown>();
        DDDifficultyChoosing.options.Clear();
        foreach (String difficulty in difficultyString)
        {
            Dropdown.OptionData optionData = new Dropdown.OptionData
            {
                text = difficulty
            };
            DDDifficultyChoosing.options.Add(optionData);
        }
        DDDifficultyChoosing.captionText.text = difficultyString[0];
        //CGSquadInfo = GameObject.Find("CMain/CGOverview/SquadInfo").GetComponent<CanvasGroup>();
        //CGPlayer1Info = GameObject.Find("CMain/CGOverview/SquadInfo/Player1Info").GetComponent<CanvasGroup>();
        //CGPlayer2Info = GameObject.Find("CMain/CGOverview/SquadInfo/Player2Info").GetComponent<CanvasGroup>();
        //CGPlayer3Info = GameObject.Find("CMain/CGOverview/SquadInfo/Player3Info").GetComponent<CanvasGroup>();
        BReady = GameObject.Find("CMain/SquadInfo/BReady").GetComponent<Button>();
        XP1PerkLevel = GameObject.Find("CMain/SquadInfo/Player1Info/PerkLevel").GetComponent<Text>();
        XP1Name = GameObject.Find("CMain/SquadInfo/Player1Info/Name").GetComponent<Text>();
        XP1Name.text = Player.currentPlayer.playerName;
        //Debug.Log(Perk.GetChineseString(Player.currentPlayer.selectedPerk));
        XP1PerkLevel.text = "等级" + Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel.ToString()
            + Perk.GetString(Player.currentPlayer.selectedPerk);

        CGPerk = GameObject.Find("CMain/CGPerk").GetComponent<CanvasGroup>();
        CGSelectingPerk = GameObject.Find("CMain/CGPerk/CGSelectingPerk").GetComponent<CanvasGroup>();
        CGPerkMM = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkMM").GetComponent<CanvasGroup>();
        CGPerkMB = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkMB").GetComponent<CanvasGroup>();
        CGPerkFR = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkFR").GetComponent<CanvasGroup>();
        CGPerkTS = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkTS").GetComponent<CanvasGroup>();
        TMMLevel = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkMM/Level").GetComponent<Text>();
        TMBLevel = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkMB/Level").GetComponent<Text>();
        TFRLevel = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkFR/Level").GetComponent<Text>();
        TTSLevel = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkTS/Level").GetComponent<Text>();
        TMMLevel.text = Player.currentPlayer.perkInfo[(int)Perk.PerkName.MM].currentLevel.ToString();
        TMBLevel.text = Player.currentPlayer.perkInfo[(int)Perk.PerkName.MB].currentLevel.ToString();
        TFRLevel.text = Player.currentPlayer.perkInfo[(int)Perk.PerkName.FR].currentLevel.ToString();
        TTSLevel.text = Player.currentPlayer.perkInfo[(int)Perk.PerkName.TS].currentLevel.ToString();

        CGAbilitiesSelected = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected").GetComponent<CanvasGroup>();
        I10Up = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability10Up");
        I10Down = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability10Down");
        I20Up = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability20Up");
        I20Down = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability20Down");
        I30Up = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability30Up");
        I30Down = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability30Down");
        I40Up = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability40Up");
        I40Down = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability40Down");
        I50Up = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability50Up");
        I50Down = GameObject.Find("CMain/CGPerk/CGAbilitiesSelected/Ability50Down");
        I10Up.GetComponent<Button>().onClick.AddListener(On10UpSelected);
        I10Down.GetComponent<Button>().onClick.AddListener(On10DownSelected);
        I20Up.GetComponent<Button>().onClick.AddListener(On20UpSelected);
        I20Down.GetComponent<Button>().onClick.AddListener(On20DownSelected);
        I30Up.GetComponent<Button>().onClick.AddListener(On30UpSelected);
        I30Down.GetComponent<Button>().onClick.AddListener(On30DownSelected);
        I40Up.GetComponent<Button>().onClick.AddListener(On40UpSelected);
        I40Down.GetComponent<Button>().onClick.AddListener(On40DownSelected);
        I50Up.GetComponent<Button>().onClick.AddListener(On50UpSelected);
        I50Down.GetComponent<Button>().onClick.AddListener(On50DownSelected);

        CGPerkConfiguration = GameObject.Find("CMain/CGPerk/CGPerkConfiguration").GetComponent<CanvasGroup>();
        TPerkConfiguration = GameObject.Find("CMain/CGPerk/CGPerkConfiguration/Scroll View/Viewport/Content").GetComponent<Text>();
        TGSelectingPerk = GameObject.Find("CMain/CGPerk/CGSelectingPerk").GetComponent<ToggleGroup>();
        TPerkMM = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkMM").GetComponent<Toggle>();
        TPerkMB = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkMB").GetComponent<Toggle>();
        TPerkFR = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkFR").GetComponent<Toggle>();
        TPerkTS = GameObject.Find("CMain/CGPerk/CGSelectingPerk/CGPerkTS").GetComponent<Toggle>();

        CGOptions = GameObject.Find("CMain/CGOptions").GetComponent<CanvasGroup>();
        DLanguage = GameObject.Find("CMain/CGOptions/DLanguage").GetComponent<Dropdown>();
        DLanguage.options.Clear();
        foreach (String ls in languageString)
        {
            Dropdown.OptionData tempData = new Dropdown.OptionData
            {
                text = ls
            };
            DLanguage.options.Add(tempData);
        }
        DLanguage.captionText.text = languageString[0];

        CGExit = GameObject.Find("CMain/CGExit").GetComponent<CanvasGroup>();
        BExitToMainMenu = GameObject.Find("CMain/CGExit/BExitToMainMenu").GetComponent<Button>();
        BExitGame = GameObject.Find("CMain/CGExit/BExitGame").GetComponent<Button>();

        outgameSettings = OutgameSettings.LoadOutgameSettings();

        Player.currentPlayer.SubscribeChangeAbility(this);
        Player.currentPlayer.SubscribeChangePerk(this);
    }

    void Start()
    {
        TGMain.SetAllTogglesOff();
        TOverview.Select();

        TGSelectingPerk.SetAllTogglesOff();
        switch(Player.currentPlayer.selectedPerk)
        {
            case Perk.PerkName.MM: TPerkMM.Select(); break;
            case Perk.PerkName.MB: TPerkMB.Select(); break;
            case Perk.PerkName.FR: TPerkFR.Select(); break;
            case Perk.PerkName.TS: TPerkTS.Select(); break;
        }
        RefreshAbilitiesImage();

        CGOverview.gameObject.SetActive(true);
        CGPerk.gameObject.SetActive(false);
        CGOptions.gameObject.SetActive(false);
        CGExit.gameObject.SetActive(false);
    }

    public void OnOverviewClick()
    {
        CGOverview.gameObject.SetActive(true);
        CGPerk.gameObject.SetActive(false);
        CGOptions.gameObject.SetActive(false);
        CGExit.gameObject.SetActive(false);
    }
    public void OnPerkClick()
    {
        CGOverview.gameObject.SetActive(false);
        CGPerk.gameObject.SetActive(true);
        CGOptions.gameObject.SetActive(false);
        CGExit.gameObject.SetActive(false);
    }
    public void OnOptionsClick()
    {
        CGOverview.gameObject.SetActive(false);
        CGPerk.gameObject.SetActive(false);
        CGOptions.gameObject.SetActive(true);
        CGExit.gameObject.SetActive(false);
    }
    public void OnOptionsExit()
    {
        CGOverview.gameObject.SetActive(false);
        CGPerk.gameObject.SetActive(false);
        CGOptions.gameObject.SetActive(false);
        CGExit.gameObject.SetActive(true);
    }

    public void OnSelectingPerk()
    {
        if (TPerkMM.isOn)
        {
            TPerkConfiguration.text = Description.MachineMastery(outgameSettings.language);
            ChangePerkEvent(this, new ChangePerkEventArgs(Perk.PerkName.MM));
        }
        if (TPerkMB.isOn)
        {
            TPerkConfiguration.text = Description.MadBomber(outgameSettings.language);
            ChangePerkEvent(this, new ChangePerkEventArgs(Perk.PerkName.MB));
        }
        if (TPerkFR.isOn)
        {
            TPerkConfiguration.text = Description.FireRanger(outgameSettings.language);
            ChangePerkEvent(this, new ChangePerkEventArgs(Perk.PerkName.FR));
        }
        if (TPerkTS.isOn)
        {
            TPerkConfiguration.text = Description.ThunderSpirit(outgameSettings.language);
            ChangePerkEvent(this, new ChangePerkEventArgs(Perk.PerkName.TS));
        }
        XP1PerkLevel.text = "等级" + Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel.ToString()
            + Perk.GetString(Player.currentPlayer.selectedPerk);
        RefreshAbilitiesImage();
    }

    void RefreshAbilitiesImage()
    {
        switch(Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[0])
        {
            case Player.PerkInfo.PerkChosenState.up: I10Up.GetComponent<Image>().color = Color.red; I10Down.GetComponent<Image>().color = Color.white; break;
            case Player.PerkInfo.PerkChosenState.down: I10Up.GetComponent<Image>().color = Color.white; I10Down.GetComponent<Image>().color = Color.red; break;
            case Player.PerkInfo.PerkChosenState.disabled: I10Up.GetComponent<Image>().color = Color.white; I10Down.GetComponent<Image>().color = Color.white; break;
        }
        switch (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[1])
        {
            case Player.PerkInfo.PerkChosenState.up: I20Up.GetComponent<Image>().color = Color.red; I20Down.GetComponent<Image>().color = Color.white; break;
            case Player.PerkInfo.PerkChosenState.down: I20Up.GetComponent<Image>().color = Color.white; I20Down.GetComponent<Image>().color = Color.red; break;
            case Player.PerkInfo.PerkChosenState.disabled: I20Up.GetComponent<Image>().color = Color.white; I20Down.GetComponent<Image>().color = Color.white; break;
        }
        switch (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[2])
        {
            case Player.PerkInfo.PerkChosenState.up: I30Up.GetComponent<Image>().color = Color.red; I30Down.GetComponent<Image>().color = Color.white; break;
            case Player.PerkInfo.PerkChosenState.down: I30Up.GetComponent<Image>().color = Color.white; I30Down.GetComponent<Image>().color = Color.red; break;
            case Player.PerkInfo.PerkChosenState.disabled: I30Up.GetComponent<Image>().color = Color.white; I30Down.GetComponent<Image>().color = Color.white; break;
        }
        switch (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[3])
        {
            case Player.PerkInfo.PerkChosenState.up: I40Up.GetComponent<Image>().color = Color.red; I40Down.GetComponent<Image>().color = Color.white; break;
            case Player.PerkInfo.PerkChosenState.down: I40Up.GetComponent<Image>().color = Color.white; I40Down.GetComponent<Image>().color = Color.red; break;
            case Player.PerkInfo.PerkChosenState.disabled: I40Up.GetComponent<Image>().color = Color.white; I40Down.GetComponent<Image>().color = Color.white; break;
        }
        switch (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[4])
        {
            case Player.PerkInfo.PerkChosenState.up: I50Up.GetComponent<Image>().color = Color.red; I50Down.GetComponent<Image>().color = Color.white; break;
            case Player.PerkInfo.PerkChosenState.down: I50Up.GetComponent<Image>().color = Color.white; I50Down.GetComponent<Image>().color = Color.red; break;
            case Player.PerkInfo.PerkChosenState.disabled: I50Up.GetComponent<Image>().color = Color.white; I50Down.GetComponent<Image>().color = Color.white; break;
        }
    }

    internal void On10UpSelected()
    {
        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 10)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[0] != Player.PerkInfo.PerkChosenState.up)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(10, Player.PerkInfo.PerkChosenState.up));
                RefreshAbilitiesImage();
            }
    }
    internal void On10DownSelected()
    {
        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 10)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[0] != Player.PerkInfo.PerkChosenState.down)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(10, Player.PerkInfo.PerkChosenState.down));
                RefreshAbilitiesImage();
            }

    }
    internal void On20UpSelected()
    {
        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 20)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[1] != Player.PerkInfo.PerkChosenState.up)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(20, Player.PerkInfo.PerkChosenState.up));
                RefreshAbilitiesImage();
            }
    }
    internal void On20DownSelected()
    {

        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 20)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[1] != Player.PerkInfo.PerkChosenState.down)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(20, Player.PerkInfo.PerkChosenState.down));
                RefreshAbilitiesImage();
            }
    }
    internal void On30UpSelected()
    {

        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 30)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[2] != Player.PerkInfo.PerkChosenState.up)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(30, Player.PerkInfo.PerkChosenState.up));
                RefreshAbilitiesImage();
            }
    }
    internal void On30DownSelected()
    {

        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 30)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[2] != Player.PerkInfo.PerkChosenState.down)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(30, Player.PerkInfo.PerkChosenState.down));
                RefreshAbilitiesImage();
            }
    }
    internal void On40UpSelected()
    {

        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 40)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[3] != Player.PerkInfo.PerkChosenState.up)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(40, Player.PerkInfo.PerkChosenState.up));
                RefreshAbilitiesImage();
            }
    }
    internal void On40DownSelected()
    {

        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 40)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[3] != Player.PerkInfo.PerkChosenState.down)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(40, Player.PerkInfo.PerkChosenState.down));
                RefreshAbilitiesImage();
            }
    }
    internal void On50UpSelected()
    {
        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 50)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[4] != Player.PerkInfo.PerkChosenState.up)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(50, Player.PerkInfo.PerkChosenState.up));
                RefreshAbilitiesImage();
            }
    }
    internal void On50DownSelected()
    {
        if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].currentLevel >= 50)
            if (Player.currentPlayer.perkInfo[(int)Player.currentPlayer.selectedPerk].abilitiesSelected[4] != Player.PerkInfo.PerkChosenState.down)
            {
                ChangeAbilityEvent(this, new ChangeAbilityEventArgs(50, Player.PerkInfo.PerkChosenState.down));
                RefreshAbilitiesImage();
            }
    }

    public void OnReadyClick()
    {
        SceneManager.LoadScene("SoloGame");
    }

    public void OnLanguageClick()
    {
        outgameSettings.language = OutgameSettings.GetLanguage(DLanguage.captionText.text);
        outgameSettings.SaveOutgameSettings();
    }

    public void OnExitToMainMenuClick()
    {
        SceneManager.LoadScene("Welcome");
    }
    public void OnExitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    public void OnChangingLanguage()
    {
        outgameSettings.language = OutgameSettings.GetLanguage(DLanguage.captionText.text);
        outgameSettings.SaveOutgameSettings();
    }
}