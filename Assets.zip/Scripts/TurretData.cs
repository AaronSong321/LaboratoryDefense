﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class TurretData
{
    public GameObject[] turretPrefab;
    internal class LevelInfo
    {
        internal int cost;
        internal int attackSpeed;
        internal int minRange = 0;
        internal int maxRange = 240;
        internal ImmediateCube ic;
        internal ExplosionCube ec;
        internal FiringCube fc;
        internal SlowCube sc;
        internal StunCube tc;
    }

    internal LevelInfo[] levels;
    internal Turret.TurretName turretName;
    internal Turret.TargetType targetType;
}