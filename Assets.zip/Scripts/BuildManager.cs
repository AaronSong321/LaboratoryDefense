﻿using System;
using System.Collections;
using System.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BuildManager : MonoBehaviour
{
    TurretData selectedTurretData;
    public TurretData[] turrets;

    private MapCube selectedMapCube;
    public Animator moneyAnimator;
    private GameManager gameManager;

    GameObject TGTurrets;
    CanvasGroup CGUpgrade;
    GameObject BUpgrade;
    GameObject BDestroy;
    Text XTurretName;

    public class SpendMoneyEventArgs: EventArgs
    {
        public int moneySpent;
        public SpendMoneyEventArgs(int moneySpent)
        {
            this.moneySpent = moneySpent;
        }
    }
    public delegate void SpendMoneyEventHandler(object sender, SpendMoneyEventArgs e);
    public event SpendMoneyEventHandler SpendMoneyEvent;

    public class ReturnMoneyEventArgs : EventArgs
    {
        public int moneyReturn;
        public ReturnMoneyEventArgs(int money)
        {
            moneyReturn = money;
        }
    }
    public delegate void ReturnMoneyEventHandler(object sender, ReturnMoneyEventArgs e);
    public event ReturnMoneyEventHandler ReturnMoneyEvent;

    void Awake()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
        TGTurrets = GameObject.Find("Canvas/TurretSwitch");
        CGUpgrade = GameObject.Find("Canvas/CGUpgrade").GetComponent<CanvasGroup>();
        BUpgrade = GameObject.Find("Canvas/CGUpgrade/BUpgrade");
        BDestroy = GameObject.Find("Canvas/CGUpgrade/BDestroy");
        XTurretName = GameObject.Find("Canvas/CGUpgrade/XTurretName").GetComponent<Text>();

        TGTurrets.GetComponent<ToggleGroup>().SetAllTogglesOff();
        ReadTurretsFromXml("Turrets.xml");
        CGUpgrade.gameObject.SetActive(false);
    }
    void Start()
    {
        gameManager.SubscribeSpendMoney(this);
        gameManager.SubscribeReturnMoney(this);
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (EventSystem.current.IsPointerOverGameObject() == false)
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;
                bool isCollider = Physics.Raycast(ray, out hit, 1000, LayerMask.GetMask("MapCube"));
                if (isCollider)
                {
                    MapCube mapCube = hit.collider.GetComponent<MapCube>();
                    if (selectedTurretData != null && mapCube.turretGo == null)
                    {
                        if (gameManager.money >= selectedTurretData.levels[0].cost)
                        {
                            SpendMoneyEvent(this, new SpendMoneyEventArgs(selectedTurretData.levels[0].cost));
                            mapCube.BuildTurret(selectedTurretData);
                        }
                        else
                        {
                            moneyAnimator.SetTrigger("Flicker");
                        }
                    }
                    else if (mapCube.turretGo != null)
                    {
                        selectedMapCube = mapCube;
                        OnSelectingMapCube();
                    }

                }
            }
        }
    }

    
    public void OnMGSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.MG];
    }
    public void OnCHSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.CH];
    }
    public void OnPBSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.PB];
    }
    public void OnSPSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.SP];
    }
    public void OnSTSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.ST];
    }
    public void OnRLSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.RL];
    }
    public void OnPMSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.PM];
    }
    public void OnPSSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.PS];
    }
    public void OnTFSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.TF];
    }
    public void OnTDSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.TD];
    }

    void OnSelectingMapCube()
    {
        if (selectedMapCube.turretData == null) return;
        int turretLevel = selectedMapCube.currentLevel;
        switch(turretLevel)
        {
            case 1:
                BUpgrade.GetComponent<Button>().interactable = true;
                BUpgrade.GetComponent<Text>().text = "升级   -￥"+selectedMapCube.turretData.levels[1].cost.ToString();
                BDestroy.GetComponent<Text>().text = "出售   +￥"+(selectedMapCube.turretData.levels[0].cost / 2).ToString();
                break;
            case 2:
                BUpgrade.GetComponent<Button>().interactable = true;
                BUpgrade.GetComponent<Text>().text = "升级   -￥" + selectedMapCube.turretData.levels[2].cost.ToString();
                BDestroy.GetComponent<Text>().text = "出售   +￥" + ((selectedMapCube.turretData.levels[0].cost + selectedMapCube.turretData.levels[1].cost) / 2).ToString();
                break;
            case 3:
                BUpgrade.GetComponent<Button>().interactable = false;
                BUpgrade.GetComponent<Text>().text = "已升至满级";
                BDestroy.GetComponent<Text>().text = "出售   +￥" + ((selectedMapCube.turretData.levels[0].cost + selectedMapCube.turretData.levels[1].cost + selectedMapCube.turretData.levels[2].cost) / 2).ToString();
                break;
        }
        XTurretName.text = Turret.GetChineseString(selectedMapCube.turretGo.GetComponent<Turret>().turretName) + "等级" + selectedMapCube.currentLevel.ToString();
        CGUpgrade.gameObject.SetActive(true);
    }
    public void OnUpgrade()
    {
        if (selectedMapCube.turretData != null)
            switch(selectedMapCube.currentLevel)
            {
                case 1:
                    if (gameManager.money >= selectedMapCube.turretData.levels[1].cost)
                    {
                        SpendMoneyEvent(this, new SpendMoneyEventArgs(selectedMapCube.turretData.levels[1].cost));
                        selectedMapCube.UpgradeTurret();
                    }
                    else moneyAnimator.SetTrigger("Flicker");
                    break;
                case 2:
                    if (gameManager.money >= selectedMapCube.turretData.levels[2].cost)
                    {
                        SpendMoneyEvent(this, new SpendMoneyEventArgs(selectedMapCube.turretData.levels[2].cost));
                        selectedMapCube.UpgradeTurret();
                    }
                    else moneyAnimator.SetTrigger("Flicker");
                    break;
            }
        CGUpgrade.gameObject.SetActive(false);
    }
    public void OnDestroyTurret()
    {
        switch (selectedMapCube.currentLevel)
        {
            case 0: break;
            case 1: ReturnMoneyEvent(this, new ReturnMoneyEventArgs(selectedMapCube.turretData.levels[0].cost / 2)); break;
            case 2: ReturnMoneyEvent(this, new ReturnMoneyEventArgs((selectedMapCube.turretData.levels[0].cost + selectedMapCube.turretData.levels[1].cost) / 2)); break;
            case 3: ReturnMoneyEvent(this, new ReturnMoneyEventArgs((selectedMapCube.turretData.levels[0].cost + selectedMapCube.turretData.levels[1].cost + selectedMapCube.turretData.levels[2].cost) / 2)); break;
        }

        selectedMapCube.DestroyTurret();
        CGUpgrade.gameObject.SetActive(false);
    }

    void ReadTurretsFromXml(string fileName = "Turrets.xml")
    {
        string filePath = Settings.GeneratePath(fileName);
        XmlReaderSettings settings = new XmlReaderSettings
        {
            IgnoreComments = true
        };

        XmlReader turretReader = XmlReader.Create(filePath, settings);
        XmlDocument turretDocument = new XmlDocument();
        turretDocument.Load(turretReader);

        XmlNode turretRootNode = turretDocument.SelectSingleNode("Turrets");
        XmlNodeList turretLists = turretRootNode.ChildNodes;

        for (int i = 0; i < turretLists.Count; i++)
        {
            turrets[i].levels = new TurretData.LevelInfo[3];
            turrets[i].turretName = (Turret.TurretName)i;
            turrets[i].targetType = Turret.GetTargetType(((XmlElement)turretLists[i]).GetAttribute("targetType"));
            for (int j = 0; j < 3; j++)
            {
                XmlElement lv1 = (XmlElement)turretLists[i].ChildNodes.Item(j);
                turrets[i].levels[j] = new TurretData.LevelInfo
                {
                    cost = Int32.Parse(lv1.GetAttribute("cost")),
                    attackSpeed = Int32.Parse(lv1.GetAttribute("attackSpeed")),
                    minRange = Int32.Parse(lv1.GetAttribute("minRange")),
                    maxRange = Int32.Parse(lv1.GetAttribute("maxRange")),
                };

                XmlElement lv1ic = (XmlElement)lv1.ChildNodes.Item(0);
                if (lv1ic.GetAttribute("enable").Equals("true"))
                    turrets[i].levels[j].ic = new ImmediateCube
                    {
                        enable = true,
                        damage = Int32.Parse(lv1ic.GetAttribute("damage")),
                        attackType = TowerDescription.GetAttackType(lv1ic.GetAttribute("attackType"))
                    };
                XmlElement lv1ec = (XmlElement)lv1.ChildNodes.Item(1);
                if (lv1ec.GetAttribute("enable").Equals("true"))
                    turrets[i].levels[j].ec = new ExplosionCube
                    {
                        enable = true,
                        damage = Int32.Parse(lv1ec.GetAttribute("damage")),
                        explosionRadius = Int32.Parse(lv1ec.GetAttribute("radius")),
                        attackType = TowerDescription.GetAttackType(lv1ec.GetAttribute("attackType"))
                    };
                XmlElement lv1fc = (XmlElement)lv1.ChildNodes.Item(2);
                if (lv1fc.GetAttribute("enable").Equals("true"))
                    turrets[i].levels[j].fc = new FiringCube
                    {
                        enable = true,
                        damage = Int32.Parse(lv1fc.GetAttribute("damage")),
                        damagePerSecond = Int32.Parse(lv1fc.GetAttribute("damagePerSecond")),
                        duration = Int32.Parse(lv1fc.GetAttribute("duration")),
                        attackType = TowerDescription.GetAttackType(lv1fc.GetAttribute("attackType"))
                    };
                XmlElement lv1sc = (XmlElement)lv1.ChildNodes.Item(3);
                if (lv1sc.GetAttribute("enable").Equals("true"))
                    turrets[i].levels[j].sc = new SlowCube
                    {
                        enable = true,
                        damage = Int32.Parse(lv1sc.GetAttribute("damage")),
                        slowSpeedPercent = Single.Parse(lv1sc.GetAttribute("effect")),
                        slowDuration = Int32.Parse(lv1sc.GetAttribute("duration")),
                        attackType = TowerDescription.GetAttackType(lv1sc.GetAttribute("attackType"))
                    };
                XmlElement lv1tc = (XmlElement)lv1.ChildNodes.Item(4);
                if (lv1tc.GetAttribute("enable").Equals("true"))
                    turrets[i].levels[j].tc = new StunCube
                    {
                        enable = true,
                        damage = Int32.Parse(lv1tc.GetAttribute("damage")),
                        possibility = Single.Parse(lv1tc.GetAttribute("possibility")),
                        stunDuration = Single.Parse(lv1tc.GetAttribute("duration")),
                        attackType = TowerDescription.GetAttackType(lv1tc.GetAttribute("attackType"))
                    };
            }
        }
    }
}
