﻿using System;
using System.Collections;
using System.Xml;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BuildManager : MonoBehaviour
{
    TurretData selectedTurretData;
    public TurretData[] turrets;
    GameObject TGTurrets;

    private MapCube selectedMapCube;
    public Animator moneyAnimator;
    //public GameObject upgradeCanvas;
    //public Button buttonUpgrade;
    private GameManager gameManager;

    CanvasGroup CGUpgrade;
    GameObject BUpgrade;
    GameObject BDestroy;
    Text XTurretName;

    public class SpendMoneyEventArgs: EventArgs
    {
        public int moneySpent;
        public SpendMoneyEventArgs(int moneySpent)
        {
            this.moneySpent = moneySpent;
        }
    }
    public delegate void SpendMoneyEventHandler(object sender, SpendMoneyEventArgs e);
    public event SpendMoneyEventHandler SpendMoneyEvent;

    void Awake()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
        TGTurrets = GameObject.Find("Canvas/TurretSwitch");
        CGUpgrade = GameObject.Find("Canvas/CGUpgrade").GetComponent<CanvasGroup>();
        BUpgrade = GameObject.Find("Canvas/CGUpgrade/BUpgrade");
        BDestroy = GameObject.Find("Canvas/CGUpgrade/BDestroy");
        XTurretName = GameObject.Find("Canvas/CGUpgrade/XTurretName").GetComponent<Text>();

        TGTurrets.GetComponent<ToggleGroup>().SetAllTogglesOff();
        ReadTurretsFromXml("Turrets.xml");
        CGUpgrade.gameObject.SetActive(false);
    }
    void Start()
    {
        gameManager.SubscribeSpendMoney(this);
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (EventSystem.current.IsPointerOverGameObject() == false)
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;
                bool isCollider = Physics.Raycast(ray, out hit, 1000, LayerMask.GetMask("MapCube"));
                if (isCollider)
                {
                    MapCube mapCube = hit.collider.GetComponent<MapCube>();
                    if (selectedTurretData != null && mapCube.turretGo == null)
                    {
                        if (gameManager.money >= selectedTurretData.level1.cost)
                        {
                            SpendMoneyEvent(this, new SpendMoneyEventArgs(selectedTurretData.level1.cost));
                            mapCube.BuildTurret(selectedTurretData);
                        }
                        else
                        {
                            moneyAnimator.SetTrigger("Flicker");
                        }
                    }
                    else if (mapCube.turretGo != null)
                    {
                        selectedMapCube = mapCube;
                        OnSelectingMapCube();
                    }

                }
            }
        }
    }

    
    public void OnMGSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.MG];
    }
    public void OnCHSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.CH];
    }
    public void OnPBSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.PB];
    }
    public void OnSPSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.SP];
    }
    public void OnSTSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.ST];
    }
    public void OnRLSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.RL];
    }
    public void OnPMSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.PM];
    }
    public void OnPSSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.PS];
    }
    public void OnTFSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.TF];
    }
    public void OnTDSelected()
    {
        selectedTurretData = turrets[(int)Turret.TurretName.TD];
    }

    void OnSelectingMapCube()
    {
        if (selectedMapCube.turretData == null) return;
        int turretLevel = selectedMapCube.currentLevel;
        switch(turretLevel)
        {
            case 1:
                BUpgrade.GetComponent<Button>().interactable = true;
                BUpgrade.GetComponent<Text>().text = "升级   -￥"+selectedMapCube.turretData.level2.cost.ToString();
                BDestroy.GetComponent<Text>().text = "出售   +￥"+(selectedMapCube.turretData.level1.cost / 2).ToString();
                break;
            case 2:
                BUpgrade.GetComponent<Button>().interactable = true;
                BUpgrade.GetComponent<Text>().text = "升级   -￥" + selectedMapCube.turretData.level3.cost.ToString();
                BDestroy.GetComponent<Text>().text = "出售   +￥" + ((selectedMapCube.turretData.level1.cost + selectedMapCube.turretData.level2.cost) / 2).ToString();
                break;
            case 3:
                BUpgrade.GetComponent<Button>().interactable = false;
                BUpgrade.GetComponent<Text>().text = "已升至满级";
                BDestroy.GetComponent<Text>().text = "出售   +￥" + ((selectedMapCube.turretData.level1.cost + selectedMapCube.turretData.level2.cost + selectedMapCube.turretData.level3.cost) / 2).ToString();
                break;
        }
        XTurretName.text = Turret.GetChineseString(selectedMapCube.turretGo.GetComponent<Turret>().turretName) + "等级" + selectedMapCube.currentLevel.ToString();
        CGUpgrade.gameObject.SetActive(true);
    }
    public void OnUpgrade()
    {
        if (selectedMapCube.turretData != null)
            switch(selectedMapCube.currentLevel)
            {
                case 1:
                    if (gameManager.money >= selectedMapCube.turretData.level2.cost)
                    {
                        SpendMoneyEvent(this, new SpendMoneyEventArgs(selectedMapCube.turretData.level2.cost));
                        selectedMapCube.UpgradeTurret();
                    }
                    else moneyAnimator.SetTrigger("Flicker");
                    break;
                case 2:
                    if (gameManager.money >= selectedMapCube.turretData.level3.cost)
                    {
                        SpendMoneyEvent(this, new SpendMoneyEventArgs(selectedMapCube.turretData.level3.cost));
                        selectedMapCube.UpgradeTurret();
                    }
                    else moneyAnimator.SetTrigger("Flicker");
                    break;
            }
        CGUpgrade.gameObject.SetActive(false);
    }
    public void OnDestroyTurret()
    {
        selectedMapCube.DestroyTurret();
        CGUpgrade.gameObject.SetActive(false);
    }

    void ReadTurretsFromXml(string fileName = "Turrets.xml")
    {
        string filePath = Settings.GeneratePath(fileName);
        XmlReaderSettings settings = new XmlReaderSettings
        {
            IgnoreComments = true
        };

        XmlReader turretReader = XmlReader.Create(filePath, settings);
        XmlDocument turretDocument = new XmlDocument();
        turretDocument.Load(turretReader);

        XmlNode turretRootNode = turretDocument.SelectSingleNode("Turrets");
        XmlNodeList turretLists = turretRootNode.ChildNodes;
        
        for (int i = 0; i < turretLists.Count; i++)
        {
            XmlElement lv1 = (XmlElement)turretLists[i].ChildNodes.Item(0);
            XmlElement lv2 = (XmlElement)turretLists[i].ChildNodes.Item(1);
            XmlElement lv3 = (XmlElement)turretLists[i].ChildNodes.Item(2);
            turrets[i].level1 = new TurretData.LevelInfo
            {
                cost = Int32.Parse(lv1.GetAttribute("cost")),
                attackSpeed = Int32.Parse(lv1.GetAttribute("attackSpeed")),
                minRange = Int32.Parse(lv1.GetAttribute("minRange")),
                maxRange = Int32.Parse(lv1.GetAttribute("maxRange"))
            };
            turrets[i].level2 = new TurretData.LevelInfo
            {
                cost = Int32.Parse(lv2.GetAttribute("cost")),
                attackSpeed = Int32.Parse(lv2.GetAttribute("attackSpeed")),
                minRange = Int32.Parse(lv2.GetAttribute("minRange")),
                maxRange = Int32.Parse(lv2.GetAttribute("maxRange"))
            };
            turrets[i].level3 = new TurretData.LevelInfo
            {
                cost = Int32.Parse(lv3.GetAttribute("cost")),
                attackSpeed = Int32.Parse(lv3.GetAttribute("attackSpeed")),
                minRange = Int32.Parse(lv3.GetAttribute("minRange")),
                maxRange = Int32.Parse(lv3.GetAttribute("maxRange"))
            };
        }
    }
}
