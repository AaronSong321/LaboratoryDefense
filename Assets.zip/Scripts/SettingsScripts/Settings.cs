﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

public class Settings
{
    public static string GeneratePath(string fileName)
    {
        string filePath = fileName;
#if UNITY_EDITOR
        filePath = Application.dataPath + "/StreamingAssets/" + fileName;
#elif UNITY_IPHONE
        filePath = Application.dataPath +"/Raw/"+fileName;  
#elif UNITY_ANDROID
        filePath = "jar:file://" + Application.dataPath + "!/assets/"+fileName;  
#else
        filePath = Application.dataPath + "/StreamingAssets/" + fileName;
#endif
        return filePath;
    }

    public static string EncodeByMd5(string str)
    {
        string cl = str;
        string pwd = "";
        MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
        byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
        for (int i = 0; i < s.Length; i++)
            pwd = pwd + s[i].ToString("X");
        return pwd;
    }
}