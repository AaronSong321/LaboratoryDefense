﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

[System.Serializable]
public class ImmediateCube
{
    public int damage;
    public TowerDescription.AttackType attackType;
    public bool enable;

    public ImmediateCube() { }
    public ImmediateCube(ImmediateCube source)
    {
        enable = true;
        damage = source.damage;
        attackType = source.attackType;
    }

    public override string ToString()
    {
        return "Normal Attack:\ndamage: " + damage + "\nattack type: " + attackType + "\n";
    }
}
