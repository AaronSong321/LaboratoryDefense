﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

[System.Serializable]
public class FiringCube
{
    public int damage;
    public TowerDescription.AttackType attackType;
    public bool enable;
    public int duration;
    public int damagePerSecond;

    public FiringCube() { }
    public FiringCube(FiringCube source)
    {
        enable = true;
        damage = source.damage;
        attackType = source.attackType;
        duration = source.duration;
        damagePerSecond = source.damagePerSecond;
    }

    public override string ToString()
    {
        StringBuilder ans = new StringBuilder();
        ans.Append("Firing Effect:\n");
        ans.Append("\tDirect Damage: " + damage + "\n");
        ans.Append("\tAttack Type: " + attackType + "\n");
        ans.Append("\tDamage Per Second: " + damagePerSecond + "\n");
        ans.Append("\tDuraion: " + duration + "\n");
        return ans.ToString();
    }
}
