﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

[System.Serializable]
public class ExplosionCube
{
    public int damage;
    public TowerDescription.AttackType attackType;
    public bool enable;
    public float explosionRadius;
    //public float explosionAttenuation;
    
    public ExplosionCube() { }
    public ExplosionCube(ExplosionCube source)
    {
        enable = true;
        damage = source.damage;
        attackType = source.attackType;
        explosionRadius = source.explosionRadius;
        //explosionAttenuation = source.explosionAttenuation;
    }

    public override String ToString()
    {
        StringBuilder ans = new StringBuilder();
        ans.Append("Explosion damage effect:\n");
        ans.Append("damge: "+damage+"\nattack type: "+attackType+"\n");
        ans.Append("explosion radius: " + explosionRadius + "\n");
        return ans.ToString();
    }
}