﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

[System.Serializable]
public class StunCube
{
    public int damage;
    public TowerDescription.AttackType attackType;
    public bool enable;
    public float stunDuration;
    public float possibility;

    public StunCube() { }
    public StunCube(StunCube source)
    {
        enable = true;
        damage = source.damage;
        attackType = source.attackType;
        stunDuration = source.stunDuration;
        possibility = source.possibility;
    }

    public override string ToString()
    {
        StringBuilder ans = new StringBuilder();
        ans.Append("Stun Effect:\n");
        ans.Append(base.ToString());
        ans.Append("\tDuration:" + stunDuration + "\n");
        ans.Append("\tPossibility: " + possibility + "\n");
        return base.ToString();
    }
}