﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

[System.Serializable]
public class SlowCube
{
    public int damage;
    public TowerDescription.AttackType attackType;
    public bool enable;
    public int slowDuration;
    public float slowSpeedPercent;

    public SlowCube() { }
    public SlowCube(SlowCube source)
    {
        enable = true;
        damage = source.damage;
        attackType = source.attackType;
        slowDuration = source.slowDuration;
        slowSpeedPercent = source.slowSpeedPercent;
    }

    public override string ToString()
    {
        StringBuilder ans = new StringBuilder();
        ans.Append("Slow Effect:\n");
        ans.Append(base.ToString());
        ans.Append("\tPercent: " + slowSpeedPercent + "\n");
        ans.Append("\tDuration: " + slowDuration + "\n");
        return base.ToString();
    }
}
