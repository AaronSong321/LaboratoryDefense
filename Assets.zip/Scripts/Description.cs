﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Description
{
    public enum ModifyMode { numeric, percentage, level, turret, enemy, attackType }
    public static string Modify(string s, ModifyMode m)
    {
        switch(m)
        {
            case ModifyMode.numeric: return "<color=cyan>" + s + "</color>";
            case ModifyMode.percentage: return "<color=lime>" + s + "</color>";
            case ModifyMode.level: return "<color=brown>" + s + "</color>";
            case ModifyMode.turret: return "<b><color=blue>" + s + "</color></b>";
            case ModifyMode.enemy: return "<b><color=red>" + s + "</color></b>";
			case ModifyMode.attackType: return "<b><color=magenta>" + s + "</color></b>";
        }
        return s;
    }

    public static String MachineMastery(OutgameSettings.Language l)
    {
        String answer="";
        switch (l)
        {
            case OutgameSettings.Language.English: answer = "Properties:\n" +
                "    "+Modify("MachineGun", ModifyMode.turret)+", Pillbox basic damage increase: 1% "+Modify("per level", ModifyMode.level)+"\n" +
                "    "+Modify("Sniper", ModifyMode.turret)+", "+Modify("CrossbowHunter", ModifyMode.turret)+" basic damage increase: 0.6% "+Modify("per level", ModifyMode.level)+"\n" +
                "    "+Modify("Sniper", ModifyMode.turret)+", "+Modify("CrossbowHunter", ModifyMode.turret)+" basic firing rate increase: 0.1 "+Modify("per level", ModifyMode.level)+"\n" +
                "    Initialize money bonus: 1.2% "+Modify("per level", ModifyMode.level)+"\n" +
                "    \n" +
                "Abilities:\n" +
                "    "+Modify("level 10", ModifyMode.level)+":\n" +
                "        Armour-piercing "+Modify("bullet", ModifyMode.attackType)+": Increase the damage of "+Modify("MachineGun", ModifyMode.turret)+", "+Modify("Sniper", ModifyMode.turret)+", "+Modify("CrossbowHunter", ModifyMode.turret)+", "+Modify("PillBox", ModifyMode.turret)+" "+Modify("25%", ModifyMode.percentage)+".\n" +
                "        Cash bonus: Every enemy killed provides a cash bonus of "+Modify("30%", ModifyMode.percentage)+".\n" +
                "    "+Modify("level 20", ModifyMode.level)+":\n" +
                "        Never fly away: Enable "+Modify("MachineGun", ModifyMode.turret)+" and "+Modify("PillBox", ModifyMode.turret)+" to shoot flying enemies.\n" +
                "        Ramrod and reload: Increase the firing rate of "+Modify("CrossbowHunter", ModifyMode.turret)+" and "+Modify("Sniper", ModifyMode.turret)+" 20.\n" +
                "    "+Modify("level 30", ModifyMode.level)+":\n" +
                "        Bullets and shells: "+Modify("MachineGun", ModifyMode.turret)+" slow enemies "+Modify("15%", ModifyMode.percentage)+"/"+Modify("20%", ModifyMode.percentage)+"/24% for 3s.\n" +
                "        All by hands: Increase the effectiveness duration of "+Modify("MolotovCocktail", ModifyMode.turret)+" 2s.\n" +
                "    "+Modify("level 40", ModifyMode.level)+":\n" +
                "        Crazy boy: Increase the firing rate of "+Modify("MachineGun", ModifyMode.turret)+" and "+Modify("PillBox", ModifyMode.turret)+" 40/50/60.\n" +
                "        Multimillionaire: Every Mamoth, BristleTank and Dragon killed provides a cash bonus of 55%, which can be overlayed from Cash bonus.\n" +
                "    "+Modify("level 50", ModifyMode.level)+":\n" +
                "        Fat penalty: Every shot from "+Modify("Sniper", ModifyMode.turret)+" will do an extra damage equal to "+Modify("20%", ModifyMode.percentage)+" of the maximum health of the target. The maximum extra damage is 900.\n" +
                "        Dud versus head: "+Modify("Rocket", ModifyMode.turret)+" can shoot in any distance; when shooting from a distance shorter than the original minimum, the rocket shell deals 4/6/8 times of the "+Modify("bullet", ModifyMode.attackType)+" damage without explosion.\n";
                break;
            case OutgameSettings.Language.Chinese: answer = "属性：\n" +
                "    "+Modify("哨兵枪", ModifyMode.turret)+"，"+Modify("机枪碉堡", ModifyMode.turret)+"伤害增加："+Modify("每级", ModifyMode.level)+"1%\n" +
                "    "+Modify("狙击塔", ModifyMode.turret)+"，"+Modify("弩炮", ModifyMode.turret)+"伤害增加："+Modify("每级", ModifyMode.level)+"0.6%\n" +
                "    "+Modify("狙击塔", ModifyMode.turret)+"，"+Modify("弩炮", ModifyMode.turret)+"攻击速度增加："+Modify("每级", ModifyMode.level)+"0.1\n" +
                "    基础金钱增加："+Modify("每级", ModifyMode.level)+"1.2%\n" +
                "\n" +
                "技能：\n" +
                "    "+Modify("等级10", ModifyMode.level)+"：\n" +
                "        穿甲弹：增加"+Modify("哨兵枪", ModifyMode.turret)+"，"+Modify("狙击塔", ModifyMode.turret)+"，"+Modify("弩炮", ModifyMode.turret)+"，"+Modify("机枪碉堡", ModifyMode.turret)+"伤害"+Modify("25%", ModifyMode.percentage)+"。\n" +
                "        现金奖励：增加杀死任意敌人的金钱奖励"+Modify("30%", ModifyMode.percentage)+"。\n" +
                "    "+Modify("等级20", ModifyMode.level)+"：\n" +
                "        别想飞走：使得"+Modify("哨兵枪", ModifyMode.turret)+"，"+Modify("机枪碉堡", ModifyMode.turret)+"可以攻击空中单位。\n" +
                "        推弹上膛：增加"+Modify("弩炮", ModifyMode.turret)+"，"+Modify("狙击塔", ModifyMode.turret)+"攻击速度20。\n" +
                "    "+Modify("等级30", ModifyMode.level)+"：\n" +
                "        枪林弹雨："+Modify("哨兵枪", ModifyMode.turret)+"，"+Modify("机枪碉堡", ModifyMode.turret)+"的攻击降低敌人移动速度"+Modify("15%", ModifyMode.percentage)+"/"+Modify("20%", ModifyMode.percentage)+"/24%，持续3s。\n" +
                "        纯手工制作：增加"+Modify("燃烧瓶", ModifyMode.turret)+"持续时间2s。\n" +
                "    "+Modify("等级40", ModifyMode.level)+"：\n" +
                "        扫射：增加"+Modify("哨兵枪", ModifyMode.turret)+"，"+Modify("机枪碉堡", ModifyMode.turret)+"攻击速度40/50/60。\n" +
                "        百万富翁：增加杀死大型敌人的金钱奖励55%，可以与现金奖励叠加。\n" +
                "    "+Modify("等级50", ModifyMode.level)+"：\n" +
                "        肥胖惩罚："+Modify("狙击塔", ModifyMode.turret)+"每次攻击对敌人造成其最大生命值"+Modify("20%", ModifyMode.percentage)+"的额外伤害，最大额外伤害为900。\n" +
                "        爆头：允许"+Modify("火箭弹", ModifyMode.turret)+"可以在任意不超过最大射程的距离开火；如果射击距离小于预定的最小射程，则会造成4/6/8倍的"+Modify("子弹", ModifyMode.attackType)+"伤害，但不发生"+Modify("爆炸", ModifyMode.attackType)+"。\n";
                break;
            default: answer = "Unknown OutgameSettings.Language pack."; break;
        }
        return answer;
    }

    public static String MadBomber(OutgameSettings.Language l)
    {
        String answer = "";
        switch(l)
        {
            case OutgameSettings.Language.English: answer = "Properties:\n" +
                "    "+Modify("SharpnelThrower", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+", "+Modify("PatriotMissile", ModifyMode.turret)+" explosion damage increase: 1% "+Modify("per level", ModifyMode.level)+"\n" +
                "    "+Modify("SharpnelThrower", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+", "+Modify("PatriotMissile", ModifyMode.turret)+" explosion range increase: 0.2% "+Modify("per level", ModifyMode.level)+"\n" +
                "    Experience gained increase: "+Modify("15%", ModifyMode.percentage)+"\n" +
                "\nAbilities:\n" +
                "    "+Modify("level 10", ModifyMode.level)+":\n" +
                "        SpeedLoader: Increase firing rate of "+Modify("PatriotMissile", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+", "+Modify("SharpnelThrower", ModifyMode.turret)+" "+Modify("20%", ModifyMode.percentage)+".\n" +
                "        Aggregation: Decrease explosion range of "+Modify("PatriotMissile", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+" 35%, but increase the explosion damage of "+Modify("PatriotMissile", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+" "+Modify("40%", ModifyMode.percentage)+". \n" +
                "    "+Modify("level 20", ModifyMode.level)+":\n" +
                "        High explosion: Increase explosion damage of "+Modify("PatriotMissile", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+", "+Modify("SharpnelThrower", ModifyMode.turret)+" "+Modify("20%", ModifyMode.percentage)+".\n" +
                "        Back off: The direct hit of "+Modify("PatriotMissile", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+" can stun the target typed tiny, common or giant for 0.4s.\n" +
                "    "+Modify("level 30", ModifyMode.level)+":\n" +
                "        A new type: "+Modify("MachineGun", ModifyMode.turret)+" and "+Modify("PillBox", ModifyMode.turret)+" deal "+Modify("explosive", ModifyMode.attackType)+" damage with an explosion range of 30.\n" +
                "        Another catastrophy: Increase "+Modify("MachineGun", ModifyMode.turret)+", "+Modify("PillBox", ModifyMode.turret)+", "+Modify("Prisim", ModifyMode.turret)+" damage "+Modify("50%", ModifyMode.percentage)+".\n" +
                "    "+Modify("level 40", ModifyMode.level)+":\n" +
                "        Snipe with "+Modify("explosive", ModifyMode.attackType)+"s: Increase range of "+Modify("PatriotMissile", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+", "+Modify("SharpnelThrower", ModifyMode.turret)+" "+Modify("30%", ModifyMode.percentage)+"." +
                "        Bully: Upgrade "+Modify("PatriotMissile", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+", "+Modify("SharpnelThrower", ModifyMode.turret)+", ignoring explosion resistance when attacking enemies typed tiny or common.\n" +
                "    "+Modify("level 50", ModifyMode.level)+":\n" +
                "        Final core: Increase "+Modify("Rocket", ModifyMode.turret)+" damage to enemies typed giant or boss "+Modify("40%", ModifyMode.percentage)+".\n" +
                "        Nuclear Bomber: Give "+Modify("Rocket", ModifyMode.turret)+" and "+Modify("PatriotMissile", ModifyMode.turret)+" a chance of 5% to release a nuclear explosion, which can deal an extra explosion, with a range of 80, damage 50 for 8s. Both the direct and following damages are typed nuclear.\n";
                break;
            case OutgameSettings.Language.Chinese: answer = "属性：\n" +
                "    "+Modify("榴弹发射器", ModifyMode.turret)+"，"+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+""+Modify("爆炸", ModifyMode.attackType)+"伤害增加："+Modify("每级", ModifyMode.level)+"1%\n" +
                "    "+Modify("榴弹发射器", ModifyMode.turret)+"，"+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+""+Modify("爆炸", ModifyMode.attackType)+"范围增加："+Modify("每级", ModifyMode.level)+"0.2%\n" +
                "    经验增加："+Modify("15%", ModifyMode.percentage)+"\n" +
                "\n技能：\n" +
                "    "+Modify("等级10", ModifyMode.level)+"：\n" +
                "        装弹器：增加"+Modify("榴弹发射器", ModifyMode.turret)+"，"+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+"攻击速度"+Modify("20%", ModifyMode.percentage)+"。\n" +
                "        密集轰炸：降低"+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+""+Modify("爆炸", ModifyMode.attackType)+"范围35%，但是"+Modify("爆炸", ModifyMode.attackType)+"伤害增加"+Modify("40%", ModifyMode.percentage)+"。\n" +
                "    "+Modify("等级20", ModifyMode.level)+"：\n" +
                "        高爆弹：增加"+Modify("榴弹发射器", ModifyMode.turret)+"，"+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+""+Modify("爆炸", ModifyMode.attackType)+"伤害"+Modify("20%", ModifyMode.percentage)+"。\n" +
                "        致退："+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+"的直接攻击会可以眩晕小型，中型或大型的敌人0.4s。\n" +
                "    "+Modify("等级30", ModifyMode.level)+"：\n" +
                "        "+Modify("爆炸", ModifyMode.attackType)+"型号："+Modify("哨兵枪", ModifyMode.turret)+"，"+Modify("机枪碉堡", ModifyMode.turret)+"造成"+Modify("爆炸", ModifyMode.attackType)+"伤害，范围为30。\n" +
                "        额外灾难：增加"+Modify("哨兵枪", ModifyMode.turret)+"，"+Modify("机枪碉堡", ModifyMode.turret)+"，"+Modify("电击塔", ModifyMode.turret)+"攻击力"+Modify("50%", ModifyMode.percentage)+"。\n" +
                "    "+Modify("等级40", ModifyMode.level)+"：\n" +
                "        远程狙击：增加"+Modify("榴弹发射器", ModifyMode.turret)+"，"+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+"最大攻击范围"+Modify("30%", ModifyMode.percentage)+"。\n" +
                "        欺凌弱小：使得"+Modify("榴弹发射器", ModifyMode.turret)+"，"+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+"攻击小型或中型敌人时无视伤害抗性。\n" +
                "    "+Modify("等级50", ModifyMode.level)+"：\n" +
                "        终极进化：增加"+Modify("导弹塔", ModifyMode.turret)+"对大型敌人或boss伤害"+Modify("40%", ModifyMode.percentage)+"。\n" +
                "        核弹井："+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+"有5%的几率打出核弹，对范围80内的敌人每秒造成50点伤害，持续8s。核弹的所有伤害均为核能。\n";
                break;
            default: answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String FireRanger(OutgameSettings.Language l)
    {
        String answer = "";
        switch(l)
        {
            case OutgameSettings.Language.English: answer = "Properties:\n" +
                "    "+Modify("FlameThrower", ModifyMode.turret)+", "+Modify("MolotovCocktail", ModifyMode.turret)+", "+Modify("Micro", ModifyMode.turret)+" "+Modify("flame", ModifyMode.attackType)+" damage increase: 1% "+Modify("per level", ModifyMode.level)+"\n" +
                "    "+Modify("SharpnelThrower", ModifyMode.turret)+", "+Modify("Rocket", ModifyMode.turret)+", "+Modify("PatriotMissile", ModifyMode.turret)+" explosion explosion damage increase: 0.4% "+Modify("per level", ModifyMode.level)+"\n" +
                "    "+Modify("Transformer", ModifyMode.turret)+" "+Modify("tesla", ModifyMode.attackType)+" damage increase: 0.4% "+Modify("per level", ModifyMode.level)+"\n" +
                "\nAbilities:\n" +
                "    "+Modify("level 10", ModifyMode.level)+":\n" +
                "        Barbecue: Increase "+Modify("flame", ModifyMode.attackType)+" damage "+Modify("25%", ModifyMode.percentage)+".\n" +
                "        Gasoline and coke: Increase "+Modify("FlameThrower", ModifyMode.turret)+", "+Modify("MolotovCocktail", ModifyMode.turret)+", Macro range "+Modify("10%", ModifyMode.percentage)+".\n" +
                "    "+Modify("level 20", ModifyMode.level)+":\n" +
                "        Well done: Increase "+Modify("flame", ModifyMode.attackType)+" duration 1s.\n" +
                "        Macro-cooked: Enemies being affected by Macro are slowed "+Modify("10%", ModifyMode.percentage)+".\n" +
                "    "+Modify("level 30", ModifyMode.level)+":\n" +
                "        Double-edged sword: Decrease Macro damage to enemies typed tiny "+Modify("50%", ModifyMode.percentage)+", but increase macro damage to enemies typed giant "+Modify("50%", ModifyMode.percentage)+".\n" +
                "        Fire Armor: Increase health point of the basement "+Modify("30%", ModifyMode.percentage)+", and decrease damage from enemies typed giant "+Modify("20%", ModifyMode.percentage)+".\n" +
                "    "+Modify("level 40", ModifyMode.level)+":\n" +
                "        FireHunter: "+Modify("CrossbowHunter", ModifyMode.turret)+" deals "+Modify("flame", ModifyMode.attackType)+" damage, and the minimum range decreases to 0.\n" +
                "        MultiHeat: Enemies can be affected by "+Modify("FlameThrower", ModifyMode.turret)+", "+Modify("MolotovCocktail", ModifyMode.turret)+", Macro at the meantime, and the damage is overlayed linearly.\n" +
                "    "+Modify("level 50", ModifyMode.level)+":\n" +
                "        Air rush: Enable Macro to attack air units.\n" +
                "        Disarm: Upgrade "+Modify("FlameThrower", ModifyMode.turret)+", "+Modify("MolotovCocktail", ModifyMode.turret)+", Macro, ignoring "+Modify("flame", ModifyMode.attackType)+" resistance when attacking enemies typed tiny, common or giant.\n";
                break;
            case OutgameSettings.Language.Chinese: answer = "属性：\n" +
                "    "+Modify("火焰喷射器", ModifyMode.turret)+"，"+Modify("燃烧瓶", ModifyMode.turret)+"，"+Modify("微波塔", ModifyMode.turret)+"伤害增加："+Modify("每级", ModifyMode.level)+"1%\n" +
                "    "+Modify("榴弹发射器", ModifyMode.turret)+"，"+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("导弹塔", ModifyMode.turret)+""+Modify("爆炸", ModifyMode.attackType)+"伤害增加："+Modify("每级", ModifyMode.level)+"0.4%\n" +
                "    "+Modify("变压器", ModifyMode.turret)+"伤害增加："+Modify("每级", ModifyMode.level)+"0.4%\n" +
                "\n技能：\n" +
                "    "+Modify("等级10", ModifyMode.level)+"：\n" +
                "        我的烤肉呢：增加"+Modify("火焰喷射器", ModifyMode.turret)+"，"+Modify("燃烧瓶", ModifyMode.turret)+"，"+Modify("微波塔", ModifyMode.turret)+"伤害"+Modify("25%", ModifyMode.percentage)+"。\n" +
                "        汽油与焦炭：增加"+Modify("火焰喷射器", ModifyMode.turret)+"，"+Modify("燃烧瓶", ModifyMode.turret)+"，"+Modify("微波塔", ModifyMode.turret)+"最大射程"+Modify("10%", ModifyMode.percentage)+"。\n" +
                "    "+Modify("等级20", ModifyMode.level)+"：\n" +
                "        全熟的烤饼：增加"+Modify("火焰喷射器", ModifyMode.turret)+"，"+Modify("燃烧瓶", ModifyMode.turret)+"，"+Modify("微波塔", ModifyMode.turret)+"的燃烧持续时间1s。\n" +
                "        缓慢烹饪：受"+Modify("微波塔", ModifyMode.turret)+"影响的敌人移动速度降低"+Modify("10%", ModifyMode.percentage)+"。\n" +
                "    "+Modify("等级30", ModifyMode.level)+"：\n" +
                "        双刃剑：降低"+Modify("微波塔", ModifyMode.turret)+"对小型敌人"+Modify("50%", ModifyMode.percentage)+"的伤害，但是增加其对大型敌人的伤害"+Modify("50%", ModifyMode.percentage)+"。\n" +
                "        火焰装甲：增加基地生命值"+Modify("30%", ModifyMode.percentage)+"，降低基地受到大型敌人伤害"+Modify("20%", ModifyMode.percentage)+"。\n" +
                "    "+Modify("等级40", ModifyMode.level)+"：\n" +
                "        火焰箭矢："+Modify("弩炮", ModifyMode.turret)+"造成火焰伤害，最小射程降低为0。这样的"+Modify("弩炮", ModifyMode.turret)+"还会享受这个职业的属性加成。\n" +
                "        反复烹饪："+Modify("火焰喷射器", ModifyMode.turret)+"，"+Modify("燃烧瓶", ModifyMode.turret)+"，"+Modify("微波塔", ModifyMode.turret)+"的灼烧效果线性叠加。\n" +
                "    "+Modify("等级50", ModifyMode.level)+"：\n" +
                "        坠机：允许"+Modify("微波塔", ModifyMode.turret)+"攻击飞行单位。\n" +
                "        缴械：使得"+Modify("火焰喷射器", ModifyMode.turret)+"，"+Modify("燃烧瓶", ModifyMode.turret)+"，"+Modify("微波塔", ModifyMode.turret)+"在攻击小型，中型或大型的敌人时无视火焰抗性。\n";
                break;
            default:answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String ThunderSpirit(OutgameSettings.Language l)
    {
        String answer = "";
        switch(l)
        {
            case OutgameSettings.Language.English: answer = "Properties:\n" +
                "    "+Modify("Prisim", ModifyMode.turret)+", "+Modify("Transformer", ModifyMode.turret)+", "+Modify("Thunder", ModifyMode.turret)+" disability duration increase: 0.7% "+Modify("per level", ModifyMode.level)+"\n" +
                "    "+Modify("Thunder", ModifyMode.turret)+" shots towards air units stun possibility increase: 0.1\n" +
                "    "+Modify("Transformer", ModifyMode.turret)+" slow duration increase: 0.2s per 10 level\n" +
                "    "+Modify("Prisim", ModifyMode.turret)+", "+Modify("Transformer", ModifyMode.turret)+", "+Modify("Thunder", ModifyMode.turret)+" damage increase: 1% "+Modify("per level", ModifyMode.level)+"\n" +
                "    "+Modify("Prisim", ModifyMode.turret)+" firing rate increase: 0.6 "+Modify("per level", ModifyMode.level)+"\n" +
                "\nAbilities:\n" +
                "    "+Modify("level 10", ModifyMode.level)+":\n" +
                "        Basic solution: Increase "+Modify("Transformer", ModifyMode.turret)+" damage "+Modify("30%", ModifyMode.percentage)+" and firing rate 15.\n" +
                "        Heavy lightening: Increase "+Modify("Thunder", ModifyMode.turret)+" stun duration 0.2s.\n" +
                "    "+Modify("level 20", ModifyMode.level)+":\n" +
                "        Seckill: The shot from "+Modify("Thunder", ModifyMode.turret)+" has a possibility of 0.1/0.2/0.3 to seckill the target enemy typed tiny or common.\n" +
                "        Every warning: The shot from "+Modify("Prisim", ModifyMode.turret)+" has a possibility of 0.25 to stun enemies typed tiny for 1s.\n" +
                "    "+Modify("level 30", ModifyMode.level)+":\n" +
                "        Rail Gun: "+Modify("Sniper", ModifyMode.turret)+" deals "+Modify("tesla", ModifyMode.attackType)+" damage, and has a possibility of 0.1 to stun the target for 0.4s. Besides, "+Modify("Sniper", ModifyMode.turret)+" enjoys the property of damage increase and disability duration increase.\n" +
                "        No pass: Increase "+Modify("Transformer", ModifyMode.turret)+" range "+Modify("30%", ModifyMode.percentage)+".\n" +
                "    "+Modify("level 40", ModifyMode.level)+":\n" +
                "        Electromagnetic pulse: "+Modify("SharpnelThrower", ModifyMode.turret)+" deals "+Modify("tesla", ModifyMode.attackType)+" damage, and slows enemies "+Modify("15%", ModifyMode.percentage)+" for 0.6s.Besides, "+Modify("SharpnelThrower", ModifyMode.turret)+" enjoys the property of damage increase and disability duration increase.\n" +
                "        Collective punishment: "+Modify("Prisim", ModifyMode.turret)+" can attack two enemies in one shot, but firing rate decreases by 30.\n" +
                "    "+Modify("level 50", ModifyMode.level)+":\n" +
                "        Electrical fire: "+Modify("Micro", ModifyMode.turret)+" deals "+Modify("tesla", ModifyMode.attackType)+" damage. Besides, "+Modify("Micro", ModifyMode.turret)+" enjoys the property of damage increase.\n" +
                "        Double damage: Every stun with "+Modify("Prisim", ModifyMode.turret)+", "+Modify("Thunder", ModifyMode.turret)+", "+Modify("Sniper", ModifyMode.turret)+", "+Modify("CrossbowHunter", ModifyMode.turret)+" deals an extra damage equal to the damage of that tower.\n";
                break;
            case OutgameSettings.Language.Chinese: answer = "属性：\n" +
                "    "+Modify("电击塔", ModifyMode.turret)+"，"+Modify("变压器", ModifyMode.turret)+"，"+Modify("闪电塔", ModifyMode.turret)+"眩晕时间增加："+Modify("每级", ModifyMode.level)+"0.7%\n" +
                "    "+Modify("闪电塔", ModifyMode.turret)+"攻击对空中单位的眩晕几率增加："+Modify("10%", ModifyMode.percentage)+"\n" +
                "    "+Modify("变压器", ModifyMode.turret)+"减速时间增加：每10级0.2s\n" +
                "    "+Modify("电击塔", ModifyMode.turret)+"，"+Modify("变压器", ModifyMode.turret)+"，"+Modify("闪电塔", ModifyMode.turret)+"伤害增加："+Modify("每级", ModifyMode.level)+"1%\n" +
                "    "+Modify("电击塔", ModifyMode.turret)+"攻击速度增加："+Modify("每级", ModifyMode.level)+"0.6\n" +
                "\n技能：\n" +
                "    "+Modify("等级10", ModifyMode.level)+"：\n" +
                "        基础方案：增加"+Modify("变压器", ModifyMode.turret)+"伤害"+Modify("30%", ModifyMode.percentage)+"和攻击速度15点。\n" +
                "        重击：增加"+Modify("闪电塔", ModifyMode.turret)+"眩晕时间0.2s。\n" +
                "    "+Modify("等级20", ModifyMode.level)+"：\n" +
                "        秒杀："+Modify("闪电塔", ModifyMode.turret)+"有"+Modify("10%", ModifyMode.percentage)+"/"+Modify("20%", ModifyMode.percentage)+"/"+Modify("30%", ModifyMode.percentage)+"的几率秒杀小型或中型的敌人。\n" +
                "        步步警告："+Modify("电击塔", ModifyMode.turret)+"对小型敌人的攻击有"+Modify("25%", ModifyMode.percentage)+"的几率造成1s的眩晕。\n" +
                "    "+Modify("等级30", ModifyMode.level)+"：\n" +
                "        轨道炮："+Modify("狙击塔", ModifyMode.turret)+"造成"+Modify("电磁", ModifyMode.attackType)+"伤害，并且有"+Modify("10%", ModifyMode.percentage)+"的几率眩晕目标0.4s。这样的"+Modify("狙击塔", ModifyMode.turret)+"还会享受这个职业的属性加成。\n" +
                "        禁止通行：增加"+Modify("变压器", ModifyMode.turret)+"射程"+Modify("30%", ModifyMode.percentage)+"。\n" +
                "    "+Modify("等级40", ModifyMode.level)+"：\n" +
                "        断电榴弹："+Modify("榴弹发射器", ModifyMode.turret)+"造成"+Modify("电磁", ModifyMode.attackType)+"伤害，并且对敌人造成"+Modify("15%", ModifyMode.percentage)+"的减速，持续0.6s。这样的"+Modify("榴弹发射器", ModifyMode.turret)+"还会享受这个职业的属性加成。\n" +
                "        密集惩罚："+Modify("电击塔", ModifyMode.turret)+"能在一次攻击中攻击两个敌人，但是攻击速度降低30。\n" +
                "    "+Modify("等级50", ModifyMode.level)+"：\n" +
                "        电火："+Modify("微波塔", ModifyMode.turret)+"造成"+Modify("电磁", ModifyMode.attackType)+"伤害。这样的"+Modify("微波塔", ModifyMode.turret)+"还会享受这个职业的属性加成\n" +
                "        双倍伤害：当"+Modify("电击塔", ModifyMode.turret)+"，"+Modify("闪电塔", ModifyMode.turret)+"，"+Modify("狙击塔", ModifyMode.turret)+"，"+Modify("弩炮", ModifyMode.turret)+"造成"+Modify("电磁", ModifyMode.attackType)+"型眩晕时，会增加一个等用于伤害来源攻击力的额外伤害。\n";
                break;
        }
        return answer;
    }

    public static String BaseballCoach(OutgameSettings.Language l)
    {
        String answer = "";
        switch(l)
        {
            case OutgameSettings.Language.English:
            case OutgameSettings.Language.Chinese: answer = "名字：棒球教练\n" +
                    "    属性：\n" +
                    "        任意塔攻击速度增加："+Modify("每级", ModifyMode.level)+"0.4%\n" +
                    "        "+Modify("哨兵枪", ModifyMode.turret)+"，"+Modify("榴弹发射器", ModifyMode.turret)+"，"+Modify("电击塔", ModifyMode.turret)+"攻击力增加："+Modify("每级", ModifyMode.level)+"0.4%\n" +
                    "    \n" +
                    "    技能：\n" +
                    "    "+Modify("等级10", ModifyMode.level)+"：\n" +
                    "        欣欣向荣：增加"+Modify("30%", ModifyMode.percentage)+"的经验获取速度。\n" +
                    "        照单全收：出售防御塔时返还80%的造塔金额。\n" +
                    "    "+Modify("等级20", ModifyMode.level)+"：\n" +
                    "        静电场：每次"+Modify("闪电塔", ModifyMode.turret)+"攻击时，都会对其射程内所有敌人造成其当前生命值2%的额外伤害，伤害类型为"+Modify("电磁", ModifyMode.attackType)+"。\n" +
                    "        基地护盾：为基地生成一个能抵挡6点伤害的护盾。这个护盾每波开始时刷新。\n" +
                    "    "+Modify("等级30", ModifyMode.level)+"：\n" +
                    "        孤注一掷：当你的防御塔数量小于等于6时，提升所有塔攻击力"+Modify("20%", ModifyMode.percentage)+"。如果小于等于3，这个数值提升到"+Modify("40%", ModifyMode.percentage)+"。\n" +
                    "        双管齐下：允许"+Modify("哨兵枪", ModifyMode.turret)+"，"+Modify("机枪碉堡", ModifyMode.turret)+"攻击一个额外的随机目标。\n" +
                    "    "+Modify("等级40", ModifyMode.level)+"：\n" +
                    "        针锋相对：如果你当前放置的所有塔主要伤害类型均相同，则无视所有敌人对这种伤害类型的抗性。\n" +
                    "        \n" +
                    "    "+Modify("等级50", ModifyMode.level)+"：\n" +
                    "        终极奥义：降低"+Modify("狙击塔", ModifyMode.turret)+"，"+Modify("火箭弹", ModifyMode.turret)+"，"+Modify("闪电塔", ModifyMode.turret)+"建造和升级价格35%。\n" +
                    "        毁天灭地：所有防御塔造成的伤害类型均为核能。\n";
                break;
        }
        return answer;
    }

    public static String Elfin(OutgameSettings.Language l)
    {
        String answer = "";
        switch(l)
        {
            case OutgameSettings.Language.English: answer = "name: Elfin\n" +
                "size: tiny\n" +
                "health point: 92\n" +
                "speed: 120\n" +
                "damage: 1\n" +
                "type: ground\n" +
                "money bonus: 7\n" +
                "resistance\n" +
                "    "+Modify("bullet", ModifyMode.attackType)+": 1\n" +
                "    "+Modify("explosive", ModifyMode.attackType)+": 0.8\n" +
                "    "+Modify("tesla", ModifyMode.attackType)+": 0.6\n" +
                "    "+Modify("flame", ModifyMode.attackType)+": 1\n" +
                "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese: answer = "名字：小精灵\n" +
                "体型：小型\n" +
                "生命值：92\n" +
                "速度：120\n" +
                "攻击力：1\n" +
                "类型：地面单位\n" +
                "金钱奖励：7\n" +
                "伤害抗性：\n" +
                "    "+Modify("子弹", ModifyMode.attackType)+"抗性：1\n" +
                "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：0.8\n" +
                "    "+Modify("电磁", ModifyMode.attackType)+"抗性：0.6\n" +
                "    火焰抗性：1\n" +
                "    核能抗性：1\n";
                break;
            default: answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String Crawler(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "name: Crawler\n" +
                 "size: tiny\n" +
                 "health point: 60\n" +
                 "speed: 200\n" +
                 "damage: 1\n" +
                 "type: ground\n" +
                 "money bonus: 7\n" +
                 "resistance\n" +
                 "    "+Modify("bullet", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("explosive", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("tesla", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("flame", ModifyMode.attackType)+": 1\n" +
                 "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字：爬行者\n" +
                 "体型：小型\n" +
                 "生命值：60\n" +
                 "速度：200\n" +
                 "攻击力：1\n" +
                 "类型：地面单位\n" +
                 "金钱奖励：7\n" +
                 "伤害抗性：\n" +
                 "    "+Modify("子弹", ModifyMode.attackType)+"抗性：1\n" +
                 "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：1\n" +
                 "    "+Modify("电磁", ModifyMode.attackType)+"抗性：1\n" +
                 "    火焰抗性：1\n" +
                 "    核能抗性：1\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String Zombie(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "name: Zombie\n" +
                 "size: tiny\n" +
                 "health point: 180\n" +
                 "speed: 80\n" +
                 "damage: 1\n" +
                 "type: ground\n" +
                 "money bonus: 13\n" +
                 "resistance\n" +
                 "    "+Modify("bullet", ModifyMode.attackType)+": 0.7\n" +
                 "    "+Modify("explosive", ModifyMode.attackType)+": 0.8\n" +
                 "    "+Modify("tesla", ModifyMode.attackType)+": 0.6\n" +
                 "    "+Modify("flame", ModifyMode.attackType)+": 1\n" +
                 "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字：僵尸\n" +
                 "体型：小型\n" +
                 "生命值：180\n" +
                 "速度：80\n" +
                 "攻击力：1\n" +
                 "类型：地面单位\n" +
                 "金钱奖励：13\n" +
                 "伤害抗性：\n" +
                 "    "+Modify("子弹", ModifyMode.attackType)+"抗性：0.7\n" +
                 "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：0.8\n" +
                 "    "+Modify("电磁", ModifyMode.attackType)+"抗性：0.6\n" +
                 "    火焰抗性：1\n" +
                 "    核能抗性：1\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String Thirsty(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "name: Thirsty\n" +
                 "size: tiny\n" +
                 "health point: 70\n" +
                 "speed: 130\n" +
                 "damage: 1\n" +
                 "type: air\n" +
                 "money bonus: 9\n" +
                 "resistance\n" +
                 "    "+Modify("bullet", ModifyMode.attackType)+": 1.2\n" +
                 "    "+Modify("explosive", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("tesla", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("flame", ModifyMode.attackType)+": 1\n" +
                 "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字：嗜血者\n" +
                 "体型：小型\n" +
                 "生命值：70\n" +
                 "速度：130\n" +
                 "攻击力：1\n" +
                 "类型：空中单位\n" +
                 "金钱奖励：9\n" +
                 "伤害抗性：\n" +
                 "    "+Modify("子弹", ModifyMode.attackType)+"抗性：1.2\n" +
                 "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：1\n" +
                 "    "+Modify("电磁", ModifyMode.attackType)+"抗性：1\n" +
                 "    火焰抗性：1\n" +
                 "    核能抗性：1\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String Butcher(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "name: Butcher\n" +
                 "size: tiny\n" +
                 "health point: 650\n" +
                 "speed: 100\n" +
                 "damage: 2\n" +
                 "type: ground\n" +
                 "money bonus: 18\n" +
                 "resistance\n" +
                 "    "+Modify("bullet", ModifyMode.attackType)+": 0.7\n" +
                 "    "+Modify("explosive", ModifyMode.attackType)+": 0.7\n" +
                 "    "+Modify("tesla", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("flame", ModifyMode.attackType)+": 1.5\n" +
                 "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字：屠夫\n" +
                 "体型：中型\n" +
                 "生命值：650\n" +
                 "速度：100\n" +
                 "攻击力：2\n" +
                 "类型：地面单位\n" +
                 "金钱奖励：18\n" +
                 "伤害抗性：\n" +
                 "    "+Modify("子弹", ModifyMode.attackType)+"抗性：0.7\n" +
                 "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：0.7\n" +
                 "    "+Modify("电磁", ModifyMode.attackType)+"抗性：1\n" +
                 "    火焰抗性：1.5\n" +
                 "    核能抗性：1\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String Unicron(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "name: Unicorn\n" +
                 "size: common\n" +
                 "health point: 750\n" +
                 "speed: 130\n" +
                 "damage: 2\n" +
                 "type: ground\n" +
                 "money bonus: 20\n" +
                 "resistance\n" +
                 "    "+Modify("bullet", ModifyMode.attackType)+": 0.8\n" +
                 "    "+Modify("explosive", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("tesla", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("flame", ModifyMode.attackType)+": 1\n" +
                 "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字：独角兽\n" +
                 "体型：中型\n" +
                 "生命值：750\n" +
                 "速度：130\n" +
                 "攻击力：2\n" +
                 "类型：地面单位\n" +
                 "金钱奖励：20\n" +
                 "伤害抗性：\n" +
                 "    "+Modify("子弹", ModifyMode.attackType)+"抗性：0.8\n" +
                 "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：1\n" +
                 "    "+Modify("电磁", ModifyMode.attackType)+"抗性：1\n" +
                 "    火焰抗性：1\n" +
                 "    核能抗性：1\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String Desolator(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "name: Desolator\n" +
                 "size: tiny\n" +
                 "health point: 900\n" +
                 "speed: 110\n" +
                 "damage: 3\n" +
                 "type: ground\n" +
                 "money bonus: 26\n" +
                 "resistance\n" +
                 "    "+Modify("bullet", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("explosive", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("tesla", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("flame", ModifyMode.attackType)+": 1\n" +
                 "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字：拾荒者\n" +
                 "体型：中型\n" +
                 "生命值：900\n" +
                 "速度：110\n" +
                 "攻击力：3\n" +
                 "类型：地面单位\n" +
                 "金钱奖励：26\n" +
                 "伤害抗性：\n" +
                 "    "+Modify("子弹", ModifyMode.attackType)+"抗性：1\n" +
                 "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：1\n" +
                 "    "+Modify("电磁", ModifyMode.attackType)+"抗性：1\n" +
                 "    火焰抗性：1\n" +
                 "    核能抗性：1\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String Manmoth(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "name: Manmoth\n" +
                 "size: giant\n" +
                 "health point: 3200\n" +
                 "speed: 110\n" +
                 "damage: 6\n" +
                 "type: ground\n" +
                 "money bonus: 55\n" +
                 "resistance\n" +
                 "    "+Modify("bullet", ModifyMode.attackType)+": 1.3\n" +
                 "    "+Modify("explosive", ModifyMode.attackType)+": 0.7\n" +
                 "    "+Modify("tesla", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("flame", ModifyMode.attackType)+": 1\n" +
                 "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字：猛犸\n" +
                 "体型：大型\n" +
                 "生命值：3200\n" +
                 "速度：110\n" +
                 "攻击力：6\n" +
                 "类型：地面单位\n" +
                 "金钱奖励：55\n" +
                 "伤害抗性：\n" +
                 "    "+Modify("子弹", ModifyMode.attackType)+"抗性：1.3\n" +
                 "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：0.7\n" +
                 "    "+Modify("电磁", ModifyMode.attackType)+"抗性：1\n" +
                 "    火焰抗性：1\n" +
                 "    核能抗性：1\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String Tank(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "name: Tank\n" +
                 "size: giant\n" +
                 "health point: 4800\n" +
                 "speed: 110\n" +
                 "damage: 1\n" +
                 "type: ground\n" +
                 "money bonus: 80\n" +
                 "resistance\n" +
                 "    "+Modify("bullet", ModifyMode.attackType)+": 0.6\n" +
                 "    "+Modify("explosive", ModifyMode.attackType)+": 1.4\n" +
                 "    "+Modify("tesla", ModifyMode.attackType)+": 0.6\n" +
                 "    "+Modify("flame", ModifyMode.attackType)+": 0.6\n" +
                 "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字：坦克\n" +
                 "体型：小型\n" +
                 "生命值：4800\n" +
                 "速度：110\n" +
                 "攻击力：8\n" +
                 "类型：地面单位\n" +
                 "金钱奖励：80\n" +
                 "伤害抗性：\n" +
                 "    "+Modify("子弹", ModifyMode.attackType)+"抗性：0.6\n" +
                 "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：1.4\n" +
                 "    "+Modify("电磁", ModifyMode.attackType)+"抗性：0.6\n" +
                 "    火焰抗性：0.6\n" +
                 "    核能抗性：1\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String Dragon(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "name: Dragon\n" +
                 "size: giant\n" +
                 "health point: 3500\n" +
                 "speed: 110\n" +
                 "damage: 7\n" +
                 "type: air\n" +
                 "money bonus: 75\n" +
                 "resistance\n" +
                 "    "+Modify("bullet", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("explosive", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("tesla", ModifyMode.attackType)+": 1\n" +
                 "    "+Modify("flame", ModifyMode.attackType)+": 0.65\n" +
                 "    nuclear: 1\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字：巨龙\n" +
                 "体型：大型\n" +
                 "生命值：3500\n" +
                 "速度：110\n" +
                 "攻击力：7\n" +
                 "类型：空中单位\n" +
                 "金钱奖励：75\n" +
                 "伤害抗性：\n" +
                 "    "+Modify("子弹", ModifyMode.attackType)+"抗性：1\n" +
                 "    "+Modify("爆炸", ModifyMode.attackType)+"抗性：1\n" +
                 "    "+Modify("电磁", ModifyMode.attackType)+"抗性：1\n" +
                 "    火焰抗性：0.65\n" +
                 "    核能抗性：1\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack.";
                break;
        }
        return answer;
    }

    public static String MachineGun(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English: answer = "Name: "+Modify("MachineGun", ModifyMode.turret)+"\n" +
                    "Damage: 35/45/55\n" +
                    "Attack Type: "+Modify("bullet", ModifyMode.attackType)+"\n" +
                    "Firing Rate: 140/210/280\n" +
                    "Range: 0-220\n" +
                    "Cost: 100\n" +
                    "Target Type: ground\n";
                break;
            case OutgameSettings.Language.Chinese: answer = "名字："+Modify("哨兵枪", ModifyMode.turret)+"\n" +
                    "伤害：36/45/55\n" +
                    "攻击类型："+Modify("子弹", ModifyMode.attackType)+"\n" +
                    "攻击速度：140/210/280\n" +
                    "射程：0-220\n" +
                    "造价：100/80/140\n" +
                    "目标类型：地面单位\n";
                break;
            default: answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String Sniper(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("Sniper", ModifyMode.turret)+"\n" +
                     "Damage: 300/520/740\n" +
                     "Attack Type: "+Modify("bullet", ModifyMode.attackType)+"\n" +
                     "Firing Rate: 50\n" +
                     "Range: 0-550\n" +
                     "Cost: 500/400/400\n" +
                     "Target Type: ground\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("狙击塔", ModifyMode.turret)+"\n" +
                     "伤害：300/520/740\n" +
                     "攻击类型："+Modify("子弹", ModifyMode.attackType)+"\n" +
                     "攻击速度：50\n" +
                     "射程：0-550\n" +
                     "造价：500/400/400\n" +
                     "目标类型：地面单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String PillBox(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("PillBox", ModifyMode.turret)+"\n" +
                     "Damage: 50/85/120\n" +
                     "Attack Type: "+Modify("bullet", ModifyMode.attackType)+"\n" +
                     "Firing Rate: 280/336/392\n" +
                     "Range: 0-260\n" +
                     "Cost: 260/280/300\n" +
                     "Target Type: ground\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("机枪碉堡", ModifyMode.turret)+"\n" +
                     "伤害：50/85/120\n" +
                     "攻击类型："+Modify("子弹", ModifyMode.attackType)+"\n" +
                     "攻击速度：280/336/392\n" +
                     "射程：0-260\n" +
                     "造价：260/280/300\n" +
                     "目标类型：地面单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String CrossbowHunter(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("CrossbowHunter", ModifyMode.turret)+"\n" +
                     "Damage: 110/220/330\n" +
                     "Attack Type: "+Modify("bullet", ModifyMode.attackType)+"\n" +
                     "Firing Rate: 70\n" +
                     "Stun Possibility: 0.07\n" +
                     "Stun Duration: 0.5/0.7/0.9\n" +
                     "Range: 100-400\n" +
                     "Cost: 210/190/190\n" +
                     "Target Type: ground or air\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("弩炮", ModifyMode.turret)+"\n" +
                     "伤害：110/220/330\n" +
                     "攻击类型："+Modify("子弹", ModifyMode.attackType)+"\n" +
                     "攻击速度：70\n" +
                     "眩晕几率：0.07\n" +
                     "眩晕时间：0.5/0.7/0.9\n" +
                     "射程：100-400\n" +
                     "造价：210/190/190\n" +
                     "目标类型：地面单位，空中单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String SharpnelThrower(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("SharpnelThrower", ModifyMode.turret)+"\n" +
                     "Damage: 70/105/140\n" +
                     "Attack Type: "+Modify("explosive", ModifyMode.attackType)+"\n" +
                     "Explosion Radius: 80/90/100\n" +
                     "Firing Rate: 84/98/112\n" +
                     "Range: 150-350/150-380/150-420\n" +
                     "Cost: 180/160/240\n" +
                     "Target Type: ground\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("榴弹发射器", ModifyMode.turret)+"\n" +
                     "伤害： 70/105/140\n" +
                     "攻击类型："+Modify("爆炸", ModifyMode.attackType)+"\n" +
                     ""+Modify("爆炸", ModifyMode.attackType)+"半径：80/90/100\n" +
                     "攻击速度：84/98/112\n" +
                     "射程：150-350/150-380/150-420\n" +
                     "造价：180/160/240\n" +
                     "目标类型：地面单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String Rocket(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("Rocket", ModifyMode.turret)+"\n" +
                     "Damage: 100/120/180\n" +
                     "Attack Type: "+Modify("bullet", ModifyMode.attackType)+"\n" +
                     "Damage: 150/250/350\n" +
                     "Attack Type: "+Modify("explosive", ModifyMode.attackType)+"\n" +
                     "Explosion Radius: 50\n" +
                     "Firing Rate: 70\n" +
                     "Range: 100-450\n" +
                     "Cost: 450/400/400\n" +
                     "Target Type: ground or air\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("火箭弹", ModifyMode.turret)+"\n" +
                     "伤害： 100/120/180\n" +
                     "攻击类型："+Modify("子弹", ModifyMode.attackType)+"\n" +
                     "伤害：150/200/250\n" +
                     "攻击类型："+Modify("爆炸", ModifyMode.attackType)+"\n" +
                     ""+Modify("爆炸", ModifyMode.attackType)+"范围：50\n" +
                     "攻击速度：70\n" +
                     "射程：100-450\n" +
                     "造价：450/400/400\n" +
                     "目标类型：地面单位，空中单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String PatriotMissile(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("PatriotMissile", ModifyMode.turret)+"\n" +
                     "Damage: 60/120/180\n" +
                     "Attack Type: "+Modify("bullet", ModifyMode.attackType)+"\n" +
                     "Damage: 120/150/200\n" +
                     "Attack Type: "+Modify("explosive", ModifyMode.attackType)+"\n" +
                     "Explosion Radius: 45\n" +
                     "Firing Rate: 56/70/84\n" +
                     "Range: 0-400\n" +
                     "Cost: 180/140/160\n" +
                     "Target Type: air\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("导弹塔", ModifyMode.turret)+"\n" +
                     "伤害： 60/120/180\n" +
                     "攻击类型："+Modify("子弹", ModifyMode.attackType)+"\n" +
                     "伤害：120/150/200\n" +
                     "攻击类型："+Modify("爆炸", ModifyMode.attackType)+"\n" +
                     ""+Modify("爆炸", ModifyMode.attackType)+"范围：45\n" +
                     "攻击速度：56/70/84\n" +
                     "射程：0-400\n" +
                     "造价：180/140/160\n" +
                     "目标类型：空中单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String Prisim(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("Prisim", ModifyMode.turret)+"\n" +
                     "Damage: 80/130/180\n" +
                     "Attack Type: "+Modify("tesla", ModifyMode.attackType)+"\n" +
                     "Firing Rate: 77\n" +
                     "Range: 0-240\n" +
                     "Cost: 135/90/90\n" +
                     "Target Type: ground\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("电击塔", ModifyMode.turret)+"\n" +
                     "伤害：80/130/180\n" +
                     "攻击类型："+Modify("电磁", ModifyMode.attackType)+"\n" +
                     "攻击速度：77\n" +
                     "射程：0-240\n" +
                     "造价：135/90/90\n" +
                     "目标类型：地面单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String Transformer(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("Transformer", ModifyMode.turret)+"\n" +
                     "Damage: 35/15/0\n" +
                     "Attack Type: "+Modify("tesla", ModifyMode.attackType)+"\n" +
                     "Slow Effect: 0.8/0.6/0.45\n" +
                     "Slow Duration: 3s\n" +
                     "Firing Rate: 70\n" +
                     "Range: 0-240/0-270/0-300\n" +
                     "Cost: 140/170/200\n" +
                     "Target Type: ground\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("变压器", ModifyMode.turret)+"\n" +
                     "伤害：35/15/0\n" +
                     "攻击类型："+Modify("电磁", ModifyMode.attackType)+"\n" +
                     "减速效果：0.8/0.6/0.45\n" +
                     "持续时间：3秒\n" +
                     "攻击速度：70\n" +
                     "射程：0-240/0-260/0-280\n" +
                     "造价：140/170/200\n" +
                     "目标类型：地面单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String Thunder(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("Thunder", ModifyMode.turret)+"\n" +
                     "Damage: 180/300/450\n" +
                     "Attack Type: "+Modify("tesla", ModifyMode.attackType)+"\n" +
                     "Firing Rate: 77\n" +
                     "Stun Possibility: 0.14/0.16/0.18\n" +
                     "Stun Duration: 0.7" +
                     "Range: 0-400\n" +
                     "Cost: 240/210/260\n" +
                     "Target Type: ground or air\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("闪电塔", ModifyMode.turret)+"\n" +
                     "伤害：180/300/450\n" +
                     "攻击类型："+Modify("电磁", ModifyMode.attackType)+"\n" +
                     "眩晕几率：0.14/0.16/0.18\n" +
                     "眩晕时间：0.7\n" +
                     "攻击速度：77\n" +
                     "射程：0-400\n" +
                     "造价：240/210/260\n" +
                     "目标类型：地面单位，空中单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String FlameThrower(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("FlameThrower", ModifyMode.turret)+"\n" +
                     "Damage: 0\n" +
                     "Attack Type: "+Modify("flame", ModifyMode.attackType)+"\n" +
                     "Damage Per Second: 30/40/46\n" +
                     "Duration: 2s\n" +
                     "Firing Rate: 300\n" +
                     "Range: 0-190\n" +
                     "Cost: 135/85/75\n" +
                     "Target Type: ground\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("火焰喷射器", ModifyMode.turret)+"\n" +
                     "直接伤害：0\n" +
                     "攻击类型：火焰\n" +
                     "灼烧伤害（每秒）：30/40/46\n" +
                     "持续时间：2秒" +
                     "攻击速度：300\n" +
                     "射程：0-190\n" +
                     "造价：135/85/75\n" +
                     "目标类型：地面单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String MolotovCocktail(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("MolotovCocktail", ModifyMode.turret)+"\n" +
                     "Damage: 0\n" +
                     "Attack Type: "+Modify("flame", ModifyMode.attackType)+"\n" +
                     "Damage Per Second: 80/85/85\n" +
                     "Duration: 5/7/10s\n" +
                     "Firing Rate: 150\n" +
                     "Range: 0-320\n" +
                     "Cost: 200/130/100\n" +
                     "Target Type: ground\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("燃烧瓶", ModifyMode.turret)+"\n" +
                     "直接伤害：0\n" +
                     "攻击类型：火焰\n" +
                     "灼烧伤害（每秒）：80/85/85\n" +
                     "持续时间：5秒/7秒/10秒" +
                     "攻击速度：150\n" +
                     "射程：0-320\n" +
                     "造价：200/130/100\n" +
                     "目标类型：地面单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }

    public static String Micro(OutgameSettings.Language l)
    {
        String answer = "";
        switch (l)
        {
            case OutgameSettings.Language.English:
                answer = "Name: "+Modify("Micro", ModifyMode.turret)+"\n" +
                     "Damage: 0\n" +
                     "Attack Type: "+Modify("flame", ModifyMode.attackType)+"\n" +
                     "Damage Per Second: 18/20/22\n" +
                     "Duration: 5s\n" +
                     "Firing Rate: 300\n" +
                     "Range: 0-400\n" +
                     "Cost: 135/85/75\n" +
                     "Target Type: ground\n";
                break;
            case OutgameSettings.Language.Chinese:
                answer = "名字："+Modify("微波塔", ModifyMode.turret)+"\n" +
                     "直接伤害：0\n" +
                     "攻击类型：火焰\n" +
                     "灼烧伤害（每秒）：18/20/22\n" +
                     "持续时间：5秒" +
                     "攻击速度：300\n" +
                     "射程：0-400\n" +
                     "造价：135/85/75\n" +
                     "目标类型：地面单位\n";
                break;
            default:
                answer = "Unknown OutgameSettings.Language pack";
                break;
        }
        return answer;
    }
}
